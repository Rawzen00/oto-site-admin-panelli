<?php
session_start();

$password = 'Ghost';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_password = htmlspecialchars($_POST['password']);

    if ($user_password === $password) {
        $_SESSION['loggedin'] = true;
        echo json_encode(['status' => 'success']);
        exit();
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Geçersiz şifre']);
        exit();
    }
}