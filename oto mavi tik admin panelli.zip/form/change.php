<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: admin.php');
    exit();
}
?>

<!DOCTYPE html>

<html lang="en" class="light-style layout-menu-fixed layout-compact " dir="ltr" data-theme="theme-default"
    data-assets-path="../assets/" data-template="vertical-menu-template-free" data-style="light">

<head>
    <title>Hi!</title>
    <meta charset="utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
    <meta name="description" content="" />
    <meta name="keywords" content="dashboard, bootstrap 5 dashboard, bootstrap 5 design, bootstrap 5">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link rel="canonical" href="https://themeselection.com/item/sneat-dashboard-pro-bootstrap/">
    <script>
    (function(w, d, s, l, i) {
        w[l] = w[l] || [];
        w[l].push({
            'gtm.start': new Date().getTime(),
            event: 'gtm.js'
        });
        var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s),
            dl = l != 'dataLayer' ? '&l=' + l : '';
        j.async = true;
        j.src =
            'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
        f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-5DDHKGP');
    </script>

    <link rel="icon" type="image/x-icon" href="../assets/img/favicon/favicon.ico" />


    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="../assets/vendor/fonts/boxicons.css" />
    <link rel="stylesheet" href="../assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="../assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="../assets/css/demo.css" />
    <link rel="stylesheet" href="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
    <script src="../assets/vendor/js/helpers.js"></script>
    <script src="../assets/js/config.js"></script>

</head>

<body>
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5DDHKGP" height="0" width="0"
            style="display: none; visibility: hidden"></iframe></noscript>

    <div class="layout-wrapper layout-content-navbar  ">
        <div class="layout-container">
            <div class="layout-page">

                <div class="content-wrapper">

                    <div class="container-xxl flex-grow-1 container-p-y">

                        <div class="row">
                            <div class="col-xxl">

                                <div class="card mb-6">
                                    <div class="card-header d-flex align-items-center justify-content-between">
                                        <h5 class="mb-0">Email Kodu Gönder</h5> <small
                                            class="text-muted float-end"></small>
                                    </div>
                                    <div class="card-body">
                                        <form id="emailchange">
                                            <div class="row mb-6">
                                                <label class="col-sm-2 col-form-label"
                                                    for="basic-default-email">Değiştirilecek Hesap</label>
                                                <div class="col-sm-10">
                                                    <select class="form-select" id="username" name="username" required>
                                                        <option selected="" disabled>Seçiniz...</option>
                                                        <?php
                                                        $klasor_yolu = 'admin/cookie';
                                                        $dosyalar = scandir($klasor_yolu);
                                                        foreach ($dosyalar as $dosya) {
                                                            if (pathinfo($dosya, PATHINFO_EXTENSION) === 'json') {
                                                                $dosya_adi = pathinfo($dosya, PATHINFO_FILENAME);
                                                                echo "<option value=\"$dosya_adi\">$dosya_adi</option>";
                                                            }
                                                        }

                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="row mb-6">
                                                <label class="col-sm-2 col-form-label"
                                                    for="basic-default-email">Email</label>
                                                <div class="col-sm-10">
                                                    <div class="input-group input-group-merge">
                                                        <input type="text" id="email" name="email" class="form-control"
                                                            placeholder="Email Adresi " aria-label="john.doe"
                                                            aria-describedby="basic-default-email2" / required>
                                                    </div>
                                                </div>
                                            </div>
                                            <br>
                                            <div class="row justify-content-end">
                                                <div class="col-sm-10">
                                                    <button id="emailchangefactor" type="submit"
                                                        class="btn btn-primary">Kod Gönder</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <br>
                                <div class="card mb-6">
                                    <div class="card-header d-flex align-items-center justify-content-between">
                                        <h5 class="mb-0">Bilgilendirme!</h5> <small
                                            class="text-muted float-end"></small>
                                    </div>
                                    <div class="card-body">
                                        <p>Mail Değişirken Hesabın İlk Değiştirilen Kullanıcı Adına Değiştirip Giriş
                                            Yaptırın. Ardından Değişin Aksi Taktirde Hata Alcan Amk Aptalı seni!</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl">
                                <br>
                                <div class="card mb-6">
                                    <div class="card-header d-flex align-items-center justify-content-between">
                                        <h5 class="mb-0">Bilgilendirme</h5>
                                    </div>
                                    <div class="card-body">
                                        <form id="loginfactors2s">
                                            <div class="row mb-6">
                                                <label class="col-sm-2 col-form-label"
                                                    for="basic-icon-default-fullname">Kullanıcı adı</label>
                                                <div class="col-sm-10">
                                                    <div class="input-group input-group-merge">
                                                        <span id="basic-icon-default-fullname2"
                                                            class="input-group-text"><i class="bx bx-user"></i></span>
                                                        <input type="text" class="form-control" id="usernamefactor"
                                                            name="usernamefactor" placeholder="Kullanıcı adı"
                                                            aria-label="Kullanıcı adı"
                                                            aria-describedby="basic-icon-default-fullname2" / required>
                                                    </div>
                                                </div>
                                            </div>
                                            <br>
                                            <div class="row mb-6">
                                                <label class="col-sm-2 col-form-label"
                                                    for="basic-icon-default-email">Şifre</label>
                                                <div class="col-sm-10">
                                                    <div class="input-group input-group-merge">
                                                        <span class="input-group-text"><i
                                                                class="bx bx-envelope"></i></span>
                                                        <input type="text" id="passwordfactor" name="passwordfactor"
                                                            class="form-control" placeholder="Şifre" aria-label="Şifre"
                                                            aria-describedby="basic-icon-default-email2" / required>

                                                    </div>
                                                    <br>
                                                </div>
                                            </div>
                                            <div class="row mb-6">
                                                <label class="col-sm-2 col-form-label"
                                                    for="basic-icon-default-phone">Yedek Kodlar</label>
                                                <div class="col-sm-10">
                                                    <div class="input-group input-group-merge">
                                                        <span id="basic-icon-default-phone2" class="input-group-text"><i
                                                                class="bx bx-phone"></i></span>
                                                        <input type="text" id="backupcode" name="backupcode"
                                                            class="form-control phone-mask" placeholder="Yedek Kodlar"
                                                            aria-label="Yedek Kodlar "
                                                            aria-describedby="basic-icon-default-phone2" / required>
                                                    </div>
                                                </div>
                                            </div>
                                            <br>
                                            <div class="row justify-content-end">
                                                <div class="col-sm-10">
                                                    <button id="loginfactorajaxbutton" type="submit"
                                                        class="btn btn-primary">Giriş Yap</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="content-backdrop fade"></div>
                </div>
            </div>
        </div>
        <div class="layout-overlay layout-menu-toggle"></div>


    </div>

    <script src="../assets/vendor/libs/jquery/jquery.js"></script>
    <script src="../assets/vendor/libs/popper/popper.js"></script>
    <script src="../assets/vendor/js/bootstrap.js"></script>
    <script src="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="../assets/vendor/js/menu.js"></script>
    <script src="../assets/js/main.js"></script>
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>

    <script>
    $(document).ready(function() {
        $('#loginfactors2s').submit(function(event) {
            event.preventDefault();


            var username = $('#usernamefactor').val();
            var password = $('#passwordfactor').val();
            var backupcode = $('#backupcode').val();
            var button = $("#loginfactorajaxbutton");

            button.html("<span class='spinner-grow spinner-grow-sm'></span> Giriş Yapılıyor...");
            button.prop('disabled', true);

            $.ajax({
                type: 'POST',
                url: 'admin/logintwo.php',
                data: {
                    username: username,
                    password: password,
                    backupcode: backupcode
                }

                ,
                success: function(response) {
                        if (response === 'succeslogin') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Başarılı!',
                                text: 'Hesaba Başarılı Bir Şekilde Giriş Yapıldı!',
                            });
                        } else if (response === 'challenge_required') {
                            Swal.fire({
                                icon: 'warning',
                                title: 'Hata!',
                                text: 'Hesaba Giriş Yapılamadı. Şüpheli Giriş Onayına Rastlandı, Lütfen 2Faktörlü Doğrulama Açarak Aşağıdaki İki Faktör Giriş Bölümünden Giriş Yapınız!',
                            });
                        } else if (response === 'badcode') {
                            Swal.fire({
                                icon: 'warning',
                                title: 'Hata!',
                                text: 'Hesaba Giriş Yapılamadı, Girdiğiniz Yedek Kodlar Hatalı!',
                            });
                        } else if (response === 'wrongpassword') {
                            Swal.fire({
                                icon: 'warning',
                                title: 'Hata!',
                                text: 'Hesaba Giriş Yapılamadı, Hatalı Şifre Girdiniz!',
                            });
                        }
                    }

                    ,
                error: function(xhr) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Hata!',
                            text: 'Veri gönderirken bir hata oluştu. Lütfen tekrar deneyin.',
                        });
                    }

                    ,
                complete: function() {
                    button.html("Giriş Yap");
                    button.prop('disabled', false);
                }
            });
        });


        $('#emailchange').submit(function(event) {
            event.preventDefault();

            var email = $('#email').val();
            var username = $('#username').val();
            var button = $("#emailchangefactor");

            button.html("<span class='spinner-grow spinner-grow-sm'></span> Kod Gönderiliyor...");
            button.prop('disabled', true);

            $.ajax({
                type: 'POST',
                url: 'admin/sendcode.php',
                data: {
                    email: email,
                    username: username,
                },
                success: function(response) {
                    if (response === 'succescode') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Başarılı!',
                            text: 'Kod Gönderme Başarılı Onaylayınız!',
                            showCancelButton: true,
                            confirmButtonText: 'Onay Kodu Gir',
                            cancelButtonText: 'Yok annem kızar'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                Swal.fire({
                                    title: '6 Haneli Kod',
                                    input: 'text',
                                    inputAttributes: {
                                        maxlength: 6,
                                        autocapitalize: 'off',
                                        autocorrect: 'off'
                                    },
                                    showCancelButton: true,
                                    confirmButtonText: 'Gönder',
                                    cancelButtonText: 'İptal',
                                    preConfirm: (code) => {
                                        if (!code || code.length !==
                                            6 || !/^\d{6}$/.test(code)
                                        ) {
                                            Swal.showValidationMessage(
                                                'Lütfen geçerli 6 haneli bir kod girin.'
                                            )
                                        } else {
                                            return code;
                                        }
                                    }
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        var code = result.value;
                                        $.ajax({
                                            type: 'POST',
                                            url: 'admin/codeverify.php',
                                            data: {
                                                code: code,
                                                username: username
                                            },
                                            success: function(
                                                response) {
                                                if (response ===
                                                    'code_success'
                                                ) {
                                                    Swal.fire({
                                                        icon: 'success',
                                                        title: 'Başarılı!',
                                                        text: 'Kod Başarıyla Doğrulandı Mail Eklendi!',
                                                    });
                                                } else {
                                                    Swal.fire({
                                                        icon: 'error',
                                                        title: 'Hata!',
                                                        text: 'Kod doğrulama başarısız.',
                                                    });
                                                }
                                            },
                                            error: function(xhr) {
                                                Swal.fire({
                                                    icon: 'error',
                                                    title: 'Hata!',
                                                    text: 'Kod gönderirken bir hata oluştu. Lütfen tekrar deneyin.',
                                                });
                                            }
                                        });
                                    }
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Hata!',
                                    text: 'Bir Hata Mevcut',
                                });
                            }
                        });
                    }
                },
                error: function(xhr) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Hata!',
                        text: 'Veri gönderirken bir hata oluştu. Lütfen tekrar deneyin.',
                    });
                },
                complete: function() {
                    button.html("Kod Gönderildi");
                    button.prop('disabled', false);
                }
            });
        });
    });
    </script>
</body>

</html>