<?php
class Setting
{

    protected $proxy;

    public function proxy()
    {
        return [
            'proxy' => '146.19.173.51',
            'auth'  => 'bluetick:Vrd123a!!gfb',
            'port' => 'orps2.hideos.com'
        ];
    }
}