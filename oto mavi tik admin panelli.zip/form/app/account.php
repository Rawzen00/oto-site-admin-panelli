<?php

namespace App\Account;

class account
{

    public function accounts2s($username)
    {
        $domain = filter_input(INPUT_SERVER, 'HTTP_HOST', FILTER_SANITIZE_URL);
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

        $directory = dirname(__FILE__);
        $parentDirectory = dirname($directory);
        $grandParentDirectory = dirname($parentDirectory);
        $grandParentDirectoryName = basename($grandParentDirectory);

        $url = $protocol . $domain . "/" . $grandParentDirectoryName . "/form/app/s2s.php?username=" . urlencode($username);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 4);
        curl_exec($ch);
        curl_close($ch);
    }
}