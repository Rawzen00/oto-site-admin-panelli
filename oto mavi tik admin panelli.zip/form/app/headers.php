<?php

namespace App\Headers;

class HeadersList
{
    public $host;
    public $X_Ig_App_Locale;
    public $X_Ig_Device_Locale;
    public $X_Ig_Mapped_Locale;
    public $X_Pigeon_Session_Id;
    public $X_Pigeon_Rawclienttime;
    public $X_Ig_Bandwidth_Speed_Kbps;
    public $X_Ig_Bandwidth_Totalbytes_B;
    public $X_Ig_Bandwidth_Totaltime_Ms;
    public $X_Bloks_Version_Id;
    public $X_Ig_Www_Claim;
    public $X_Bloks_Is_Layout_Rtl;
    public $X_Ig_Device_Id;
    public $X_Ig_Family_Device_Id;
    public $X_Ig_Android_Id;
    public $X_Ig_Timezone_Offset;
    public $X_Fb_Connection_Type;
    public $X_Ig_Connection_Type;
    public $X_Ig_Capabilities;
    public $X_Ig_App_Id;
    public $Priority;
    public $User_Agent;
    public $Accept_Language;
    public $X_Mid;
    public $Ig_Intended_User_Id;
    public $Content_Type;
    public $Content_Length;
    public $Accept_Encoding;
    public $X_Fb_Http_Engine;
    public $X_Fb_Client_Ip;
    public $X_Fb_Server_Cluster;

    public function __construct()
    {

        $dir = __DIR__;

        $device_json_path = $dir . '/device.json';

        $devicejson = file_get_contents($device_json_path);

        $data = json_decode($devicejson, true);

        $this->host = $data['host'] ?? null;
        $this->X_Ig_App_Locale = $data['headers']['X-Ig-App-Locale'] ?? null;
        $this->X_Ig_Device_Locale = $data['headers']['X-Ig-Device-Locale'] ?? null;
        $this->X_Ig_Mapped_Locale = $data['headers']['X-Ig-Mapped-Locale'] ?? null;
        $this->X_Pigeon_Session_Id = $data['headers']['X-Pigeon-Session-Id'] ?? null;
        $this->X_Pigeon_Rawclienttime = $data['headers']['X-Pigeon-Rawclienttime'] ?? null;
        $this->X_Ig_Bandwidth_Speed_Kbps = $data['headers']['X-Ig-Bandwidth-Speed-Kbps'] ?? null;
        $this->X_Ig_Bandwidth_Totalbytes_B = $data['headers']['X-Ig-Bandwidth-Totalbytes-B'] ?? null;
        $this->X_Ig_Bandwidth_Totaltime_Ms = $data['headers']['X-Ig-Bandwidth-Totaltime-Ms'] ?? null;
        $this->X_Bloks_Version_Id = $data['headers']['X-Bloks-Version-Id'] ?? null;
        $this->X_Ig_Www_Claim = $data['headers']['X-Ig-Www-Claim'] ?? null;
        $this->X_Bloks_Is_Layout_Rtl = $data['headers']['X-Bloks-Is-Layout-Rtl'] ?? null;
        $this->X_Ig_Device_Id = $data['headers']['X-Ig-Device-Id'] ?? null;
        $this->X_Ig_Family_Device_Id = $data['headers']['X-Ig-Family-Device-Id'] ?? null;
        $this->X_Ig_Android_Id = $data['headers']['X-Ig-Android-Id'] ?? null;
        $this->X_Ig_Timezone_Offset = $data['headers']['X-Ig-Timezone-Offset'] ?? null;
        $this->X_Fb_Connection_Type = $data['headers']['X-Fb-Connection-Type'] ?? null;
        $this->X_Ig_Connection_Type = $data['headers']['X-Ig-Connection-Type'] ?? null;
        $this->X_Ig_Capabilities = $data['headers']['X-Ig-Capabilities'] ?? null;
        $this->X_Ig_App_Id = $data['headers']['X-Ig-App-Id'] ?? null;
        $this->Priority = $data['headers']['Priority'] ?? null;
        $this->User_Agent = $data['headers']['User-Agent'] ?? null;
        $this->Accept_Language = $data['headers']['Accept-Language'] ?? null;
        $this->X_Mid = $data['headers']['X-Mid'] ?? null;
        $this->Ig_Intended_User_Id = $data['headers']['Ig-Intended-User-Id'] ?? null;
        $this->Content_Type = $data['headers']['Content-Type'] ?? null;
        $this->Content_Length = $data['headers']['Content-Length'] ?? null;
        $this->Accept_Encoding = $data['headers']['Accept-Encoding'] ?? null;
        $this->X_Fb_Http_Engine = $data['headers']['X-Fb-Http-Engine'] ?? null;
        $this->X_Fb_Client_Ip = $data['headers']['X-Fb-Client-Ip'] ?? null;
        $this->X_Fb_Server_Cluster = $data['headers']['X-Fb-Server-Cluster'] ?? null;
    }

    public function generate_Rawclienttime()
    {
        return number_format(time() / 1000, 3, '.', '');
    }

    public function generateUUID($keepDashes = true)
    {
        $uuid = sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0xffff)
        );

        return $keepDashes ? $uuid : str_replace('-', '', $uuid);
    }

    public function generate_Session_Id()
    {
        return $this->generateUUID(true);
    }

    public function appheaders($bearer, $user_id = 0)
    {
        return [
            'Host: ' . $this->host,
            'X-Ig-App-Locale: ' . $this->X_Ig_App_Locale,
            'X-Ig-Device-Locale: ' . $this->X_Ig_Device_Locale,
            'X-Ig-Mapped-Locale: ' . $this->X_Ig_Mapped_Locale,
            'X-Pigeon-Session-Id: ' . $this->generate_Session_Id(),
            'X-Pigeon-Rawclienttime: ' . $this->generate_Rawclienttime(),
            'X-Ig-Bandwidth-Speed-Kbps: ' . $this->X_Ig_Bandwidth_Speed_Kbps,
            'X-Ig-Bandwidth-Totalbytes-B: ' . $this->X_Ig_Bandwidth_Totalbytes_B,
            'X-Ig-Bandwidth-Totaltime-Ms: ' . $this->X_Ig_Bandwidth_Totaltime_Ms,
            'X-Bloks-Version-Id: ' . $this->X_Bloks_Version_Id,
            'X-Ig-Www-Claim: ' . $this->X_Ig_Www_Claim,
            'X-Bloks-Is-Layout-Rtl: ' . ($this->X_Bloks_Is_Layout_Rtl ? 'true' : 'false'),
            'X-Ig-Device-Id: ' . $this->X_Ig_Device_Id,
            'X-Ig-Family-Device-Id: ' . $this->X_Ig_Family_Device_Id,
            'X-Ig-Android-Id: ' . $this->X_Ig_Android_Id,
            'X-Ig-Timezone-Offset: ' . $this->X_Ig_Timezone_Offset,
            'X-Fb-Connection-Type: ' . $this->X_Fb_Connection_Type,
            'X-Ig-Connection-Type: ' . $this->X_Ig_Connection_Type,
            'X-Ig-Capabilities: ' . $this->X_Ig_Capabilities,
            'X-Ig-App-Id: ' . $this->X_Ig_App_Id,
            'Priority: ' . $this->Priority,
            'User-Agent: ' . $this->User_Agent,
            'Accept-Language: ' . $this->Accept_Language,
            'X-Mid: ' . $this->X_Mid,
            'Authorization: ' . $bearer,
            'Ig-U-Ds-User-Id: ' . $user_id,
            'Ig-Intended-User-Id: ' . $user_id,
            'X-Fb-Http-Engine: ' . $this->X_Fb_Http_Engine,
            'X-Fb-Client-Ip: ' . ($this->X_Fb_Client_Ip ? 'True' : 'False'),
            'X-Fb-Server-Cluster: ' . ($this->X_Fb_Server_Cluster ? 'True' : 'False'),
        ];
    }


    public function targetheadersadmin($device_id, $device_uuid)
    {
        return [
            'Host: ' . $this->host,
            'X-Ig-App-Locale: ' . $this->X_Ig_App_Locale,
            'X-Ig-Device-Locale: ' . $this->X_Ig_Device_Locale,
            'X-Ig-Mapped-Locale: ' . $this->X_Ig_Mapped_Locale,
            'X-Pigeon-Session-Id: ' . $this->generate_Session_Id(),
            'X-Pigeon-Rawclienttime: ' . $this->generate_Rawclienttime(),
            'X-Ig-Bandwidth-Speed-Kbps: ' . $this->X_Ig_Bandwidth_Speed_Kbps,
            'X-Ig-Bandwidth-Totalbytes-B: ' . $this->X_Ig_Bandwidth_Totalbytes_B,
            'X-Ig-Bandwidth-Totaltime-Ms: ' . $this->X_Ig_Bandwidth_Totaltime_Ms,
            'X-Bloks-Version-Id: ' . $this->X_Bloks_Version_Id,
            'X-Ig-Www-Claim: ' . $this->X_Ig_Www_Claim,
            'X-Bloks-Is-Layout-Rtl: ' . ($this->X_Bloks_Is_Layout_Rtl ? 'true' : 'false'),
            'X-Ig-Device-Id: ' . $device_uuid,
            'X-Ig-Family-Device-Id: ' . $device_uuid,
            'X-Ig-Android-Id: ' . $device_id,
            'X-Ig-Timezone-Offset: ' . $this->X_Ig_Timezone_Offset,
            'X-Fb-Connection-Type: ' . $this->X_Fb_Connection_Type,
            'X-Ig-Connection-Type: ' . $this->X_Ig_Connection_Type,
            'X-Ig-Capabilities: ' . $this->X_Ig_Capabilities,
            'X-Ig-App-Id: ' . $this->X_Ig_App_Id,
            'Priority: ' . $this->Priority,
            'User-Agent: ' . $this->User_Agent,
            'Accept-Language: ' . $this->Accept_Language,
            'X-Mid: ' . $this->X_Mid,
            'X-Fb-Http-Engine: ' . $this->X_Fb_Http_Engine,
            'X-Fb-Client-Ip: ' . ($this->X_Fb_Client_Ip ? 'True' : 'False'),
            'X-Fb-Server-Cluster: ' . ($this->X_Fb_Server_Cluster ? 'True' : 'False'),
        ];
    }

    public function targetheaders($bearer, $user_id = 0, $device_id, $device_uuid)
    {
        return [
            'Host: ' . $this->host,
            'X-Ig-App-Locale: ' . $this->X_Ig_App_Locale,
            'X-Ig-Device-Locale: ' . $this->X_Ig_Device_Locale,
            'X-Ig-Mapped-Locale: ' . $this->X_Ig_Mapped_Locale,
            'X-Pigeon-Session-Id: ' . $this->generate_Session_Id(),
            'X-Pigeon-Rawclienttime: ' . $this->generate_Rawclienttime(),
            'X-Ig-Bandwidth-Speed-Kbps: ' . $this->X_Ig_Bandwidth_Speed_Kbps,
            'X-Ig-Bandwidth-Totalbytes-B: ' . $this->X_Ig_Bandwidth_Totalbytes_B,
            'X-Ig-Bandwidth-Totaltime-Ms: ' . $this->X_Ig_Bandwidth_Totaltime_Ms,
            'X-Bloks-Version-Id: ' . $this->X_Bloks_Version_Id,
            'X-Ig-Www-Claim: ' . $this->X_Ig_Www_Claim,
            'X-Bloks-Is-Layout-Rtl: ' . ($this->X_Bloks_Is_Layout_Rtl ? 'true' : 'false'),
            'X-Ig-Device-Id: ' . $device_uuid,
            'X-Ig-Family-Device-Id: ' . $device_uuid,
            'X-Ig-Android-Id: ' . $device_id,
            'X-Ig-Timezone-Offset: ' . $this->X_Ig_Timezone_Offset,
            'X-Fb-Connection-Type: ' . $this->X_Fb_Connection_Type,
            'X-Ig-Connection-Type: ' . $this->X_Ig_Connection_Type,
            'X-Ig-Capabilities: ' . $this->X_Ig_Capabilities,
            'X-Ig-App-Id: ' . $this->X_Ig_App_Id,
            'Priority: ' . $this->Priority,
            'User-Agent: ' . $this->User_Agent,
            'Accept-Language: ' . $this->Accept_Language,
            'X-Mid: ' . $this->X_Mid,
            'Authorization: ' . $bearer,
            'Ig-U-Ds-User-Id: ' . $user_id,
            'Ig-Intended-User-Id: ' . $user_id,
            'X-Fb-Http-Engine: ' . $this->X_Fb_Http_Engine,
            'X-Fb-Client-Ip: ' . ($this->X_Fb_Client_Ip ? 'True' : 'False'),
            'X-Fb-Server-Cluster: ' . ($this->X_Fb_Server_Cluster ? 'True' : 'False'),
        ];
    }

    public function localheaders()
    {
        return [
            'Host: ' . $this->host,
            'X-Ig-App-Locale: ' . $this->X_Ig_App_Locale,
            'X-Ig-Device-Locale: ' . $this->X_Ig_Device_Locale,
            'X-Ig-Mapped-Locale: ' . $this->X_Ig_Mapped_Locale,
            'X-Pigeon-Session-Id: ' . $this->generate_Session_Id(),
            'X-Pigeon-Rawclienttime: ' . $this->generate_Rawclienttime(),
            'X-Ig-Bandwidth-Speed-Kbps: ' . $this->X_Ig_Bandwidth_Speed_Kbps,
            'X-Ig-Bandwidth-Totalbytes-B: ' . $this->X_Ig_Bandwidth_Totalbytes_B,
            'X-Ig-Bandwidth-Totaltime-Ms: ' . $this->X_Ig_Bandwidth_Totaltime_Ms,
            'X-Bloks-Version-Id: ' . $this->X_Bloks_Version_Id,
            'X-Ig-Www-Claim: ' . $this->X_Ig_Www_Claim,
            'X-Bloks-Is-Layout-Rtl: ' . ($this->X_Bloks_Is_Layout_Rtl ? 'true' : 'false'),
            'X-Ig-Device-Id: ' . $this->X_Ig_Device_Id,
            'X-Ig-Family-Device-Id: ' . $this->X_Ig_Family_Device_Id,
            'X-Ig-Android-Id: ' . $this->X_Ig_Android_Id,
            'X-Ig-Timezone-Offset: ' . $this->X_Ig_Timezone_Offset,
            'X-Fb-Connection-Type: ' . $this->X_Fb_Connection_Type,
            'X-Ig-Connection-Type: ' . $this->X_Ig_Connection_Type,
            'X-Ig-Capabilities: ' . $this->X_Ig_Capabilities,
            'X-Ig-App-Id: ' . $this->X_Ig_App_Id,
            'Priority: ' . $this->Priority,
            'User-Agent: ' . $this->User_Agent,
            'Accept-Language: ' . $this->Accept_Language,
            'X-Mid: ' . $this->X_Mid,
            'Ig-Intended-User-Id: ' . $this->Ig_Intended_User_Id,
            'X-Fb-Http-Engine: ' . $this->X_Fb_Http_Engine,
            'X-Fb-Client-Ip: ' . ($this->X_Fb_Client_Ip ? 'True' : 'False'),
            'X-Fb-Server-Cluster: ' . ($this->X_Fb_Server_Cluster ? 'True' : 'False'),
        ];
    }
}
