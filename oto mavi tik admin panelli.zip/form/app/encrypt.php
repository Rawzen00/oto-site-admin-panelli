<?php

namespace App\Encrypt;

require_once 'headers.php';

use App\Headers\HeadersList;

class encrypts
{

    private $headersList;

    public function __construct()
    {
        $this->headersList = new HeadersList();
    }

    public function generateRandomUUID()
    {
        $characters = '0123456789abcdef';
        $charactersLength = strlen($characters);
        $uuid = '';
        $sections = [8, 4, 4, 4, 12];
        foreach ($sections as $section) {
            for ($i = 0; $i < $section; $i++) {
                $uuid .= $characters[rand(0, $charactersLength - 1)];
            }
            $uuid .= '-';
        }
        $uuid = rtrim($uuid, '-');
        return $uuid;
    }

    public function generateRandomAndroidId()
    {
        $prefix = "android-";
        $characters = '0123456789abcdef';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < 16; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        $androidId = $prefix . $randomString;
        return $androidId;
    }

    public function generateRandomFamilyDeviceId()
    {
        $characters = '0123456789abcdef';
        $charactersLength = strlen($characters);
        $uuid = '';
        $sections = [8, 4, 4, 4, 12];
        foreach ($sections as $section) {
            for ($i = 0; $i < $section; $i++) {
                $uuid .= $characters[rand(0, $charactersLength - 1)];
            }
            $uuid .= '-';
        }
        $uuid = rtrim($uuid, '-');
        return $uuid;
    }

    public function generate_Rawclienttime()
    {
        return number_format(time() / 1000, 3, '.', '');
    }

    public function generateUUID($keepDashes = true)
    {
        $uuid = sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0xffff)
        );

        return $keepDashes ? $uuid : str_replace('-', '', $uuid);
    }

    public function generate_Session_Id()
    {
        return $this->generateUUID(true);
    }

    public function generateRandomUserAgent()
    {
        $versions = ['237.0.0.14.102', '237.0.0.14.102', '237.0.0.14.102'];
        $androidVersions = ['25/7.1.2', '26/8.0.0', '27/8.1.0', '28/9'];
        $dpIs = ['240dpi', '320dpi', '480dpi'];
        $resolutions = ['720x1280', '1080x1920', '1440x2560'];
        $brands = ['samsung', 'huawei', 'xiaomi'];
        $models = ['SM-G971N', 'SM-G975F', 'HUAWEI P30', 'Xiaomi Mi 9'];
        $hardware = ['beyond1q', 'beyond2q', 'POT-LX1', 'cepheus'];
        $processors = ['qcom', 'exynos', 'kirin'];
        $locales = ['tr_TR', 'en_US', 'es_ES'];
        $numbers = ['373310563', '482510273', '593720384'];

        $version = $versions[array_rand($versions)];
        $androidVersion = $androidVersions[array_rand($androidVersions)];
        $dpi = $dpIs[array_rand($dpIs)];
        $resolution = $resolutions[array_rand($resolutions)];
        $brand = $brands[array_rand($brands)];
        $model = $models[array_rand($models)];
        $hardware = $hardware[array_rand($hardware)];
        $processor = $processors[array_rand($processors)];
        $locale = $locales[array_rand($locales)];
        $number = $numbers[array_rand($numbers)];

        return "Instagram $version Android ($androidVersion; $dpi; $resolution; $brand; $model; $hardware; $processor; $locale; $number)";
    }

    public function generateRandomPassword($length = 10)
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomPassword = '';
        for ($i = 0; $i < $length; $i++) {
            $randomPassword .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomPassword;
    }

    public function generateRandomusername($length = 12)
    {
        $characters = 'abcdefghijklmnopqrstuvwxyz';
        $charactersLength = strlen($characters);
        $randomPassword = '';
        for ($i = 0; $i < $length; $i++) {
            $randomPassword .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomPassword;
    }

    public function generateMidId($length = 32)
    {

        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
        $midId = '';
        for ($i = 0; $i < $length; $i++) {
            $midId .= $chars[random_int(0, strlen($chars) - 1)];
        }

        return $midId;
    }

    public function generateSessionId()
    {
        $chars = 'abcdefghijklmnopqrstuvwxyz0123456789';

        $uuid = '';
        for ($i = 0; $i < 8; $i++) {
            $uuid .= $chars[random_int(0, strlen($chars) - 1)];
        }
        $uuid .= '-';
        for ($i = 0; $i < 4; $i++) {
            $uuid .= $chars[random_int(0, strlen($chars) - 1)];
        }
        $uuid .= '-4';
        for ($i = 0; $i < 3; $i++) {
            $uuid .= $chars[random_int(0, strlen($chars) - 1)];
        }
        $uuid .= '-';
        $uuid .= $chars[random_int(8, 9)];
        for ($i = 0; $i < 3; $i++) {
            $uuid .= $chars[random_int(0, strlen($chars) - 1)];
        }
        $uuid .= '-';
        for ($i = 0; $i < 12; $i++) {
            $uuid .= $chars[random_int(0, strlen($chars) - 1)];
        }

        return 'UFS-' . $uuid . '-' . random_int(0, 9);
    }

    public function get_sync()
    {

        $headers = $this->headersList->localheaders();

        $post_data = [
            'id' => 'd74842cb-1e48-4293-ad89-75d944ff6618',
            'server_config_retrieval' => '1',
            'experiments' => "ig_growth_android_profile_pic_prefill_with_fb_pic_2,ig_account_identity_logged_out_signals_global_holdout_universe,ig_android_caption_typeahead_fix_on_o_universe,ig_android_retry_create_account_universe,ig_android_gmail_oauth_in_reg,ig_android_quickcapture_keep_screen_on,ig_android_smartlock_hints_universe,ig_android_reg_modularization_universe,ig_android_login_identifier_fuzzy_match,ig_android_passwordless_account_password_creation_universe,ig_android_security_intent_switchoff,ig_android_sim_info_upload,ig_android_device_verification_fb_signup,ig_android_reg_nux_headers_cleanup_universe,ig_android_direct_main_tab_universe_v2,ig_android_nux_add_email_device,ig_android_fb_account_linking_sampling_freq_universe,ig_android_device_info_foreground_reporting,ig_android_suma_landing_page,ig_android_device_verification_separate_endpoint,ig_android_direct_add_direct_to_android_native_photo_share_sheet,ig_android_device_detection_info_upload,ig_android_device_based_country_verification",
        ];

        $ch = curl_init('https://i.instagram.com/api/v1/launcher/mobileconfig/');

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(['signed_body' => 'SIGNATURE.' . json_encode($post_data)]));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_HEADER, true);

        $response = curl_exec($ch);

        curl_close($ch);

        if ($response) {
            $headersArray = explode("\r\n", $response);
            foreach ($headersArray as $header) {
                if (strpos($header, 'ig-set-password-encryption-key-id') !== false) {
                    $result['pub_key_id'] = trim(explode(':', $header, 2)[1]);
                } elseif (strpos($header, 'ig-set-password-encryption-pub-key') !== false) {
                    $result['pub_key'] = trim(explode(':', $header, 2)[1]);
                }
            }
        }

        return $result;
    }

    public function encrypt($password)
    {

        $keys = $this->get_sync();
        $public_key = $keys['pub_key'];
        $public_key_id = $keys['pub_key_id'];

        $key = openssl_random_pseudo_bytes(32);
        $iv = openssl_random_pseudo_bytes(12);
        $time = time();

        openssl_public_encrypt($key, $encryptedAesKey, base64_decode($public_key));
        $encrypted = openssl_encrypt($password, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, strval($time));

        $payload = base64_encode("\x01" | pack('n', intval($public_key_id)) . $iv . pack('s', strlen($encryptedAesKey)) . $encryptedAesKey . $tag . $encrypted);

        return sprintf('#PWD_INSTAGRAM:4:%s:%s', $time, ($payload));
    }
}