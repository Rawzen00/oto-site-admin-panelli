<?php

namespace App\Request;

class Requests
{
    public function proxy()
    {
        return [
            'proxy' => '146.19.173.5',
            'auth'  => 'bluetick:Vrd123a!!gfb',
            'port' => 'orps2.hideos.com'
        ];
    }

    public function RequestPOSTmail($endpoint, $headers, $post)
    {
        $url = 'https://api.mail.tm/' . $endpoint;

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_PROXY, $this->proxy()['proxy']);
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $this->proxy()['auth']);
        curl_setopt($ch, CURLOPT_PROXYPORT, $this->proxy()['port']);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post));

        $response = curl_exec($ch);

        curl_close($ch);

        return $response;
    }


    public function RequestGETmail($endpoint, $headers)
    {
        $url = 'https://api.mail.tm/' . $endpoint;


        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_PROXY, $this->proxy()['proxy']);
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $this->proxy()['auth']);
        curl_setopt($ch, CURLOPT_PROXYPORT, $this->proxy()['port']);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);

        $response = curl_exec($ch);

        curl_close($ch);

        return $response;
    }

    public function requesttelegram($url, $data)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }


    public function RequestGETendpoint($endpoint, $headers)
    {
        $url = 'https://i.instagram.com/api/v1/' . $endpoint;

        $retry_count = 6;
        $attempt = 0;
        $response = '';

        while ($attempt < $retry_count) {
            $ch = curl_init();

            curl_setopt($ch, CURLOPT_PROXY, $this->proxy()['proxy']);
            curl_setopt($ch, CURLOPT_PROXYUSERPWD, $this->proxy()['auth']);
            curl_setopt($ch, CURLOPT_PROXYPORT, $this->proxy()['port']);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_ENCODING, "");
            curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);

            $response = curl_exec($ch);

            if (curl_errno($ch)) {
                $error_code = curl_errno($ch);
                $error_message = curl_error($ch);

                $error_log = "Curl Hatası [Kod: $endpoint]: $error_message";

                $log_filename = "../log/" . basename($error_code) . "_" . date("Y-m-d_H-i-s") . ".log";
                file_put_contents($log_filename, $error_log);

                usleep(1000000);

                $attempt++;
            } else {
                break;
            }

            curl_close($ch);
        }

        return $response;
    }

    public function RequestGETnotendpoint($url, $headers)
    {

        $retry_count = 6;
        $attempt = 0;
        $response = '';

        while ($attempt < $retry_count) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_PROXY, $this->proxy()['proxy']);
            curl_setopt($ch, CURLOPT_PROXYUSERPWD, $this->proxy()['auth']);
            curl_setopt($ch, CURLOPT_PROXYPORT, $this->proxy()['port']);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_ENCODING, "");
            curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);

            $response = curl_exec($ch);

            if (curl_errno($ch)) {
                $error_code = curl_errno($ch);
                $error_message = curl_error($ch);

                $error_log = "Curl Hatası [Kod: $url]: $error_message";

                $log_filename = "../log/" . basename($error_code) . "_" . date("Y-m-d_H-i-s") . ".log";
                file_put_contents($log_filename, $error_log);

                usleep(1000000);

                $attempt++;
            } else {
                break;
            }

            curl_close($ch);
        }

        return $response;
    }

    public function RequestPostnotendpoint($endpoint, $headers, $post)
    {
        $url = 'https://i.instagram.com/api/v1/' . $endpoint;

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_PROXY, $this->proxy()['proxy']);
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $this->proxy()['auth']);
        curl_setopt($ch, CURLOPT_PROXYPORT, $this->proxy()['port']);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_ENCODING, "");
        curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);


        $retry_count = 6;
        $attempt = 0;
        $response = '';

        while ($attempt < $retry_count) {
            $response = curl_exec($ch);

            if (curl_errno($ch)) {

                $error_code = curl_errno($ch);
                $error_message = curl_error($ch);

                $error_log = "Curl Hatası [Kod: $endpoint]: $error_message";
                $log_filename = "../log/" . basename($error_code) . "_" . date("Y-m-d_H-i-s") . ".log";
                file_put_contents($log_filename, $error_log);

                usleep(1000000);

                $attempt++;
            } else {
                break;
            }
        }

        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $headers = substr($response, 0, $headerSize);
        $body = substr($response, $headerSize);

        curl_close($ch);

        return [
            'headers' => $headers,
            'body' => $body,
        ];
    }




    public function RequestPostendpoint($endpoint, $headers, $post)
    {
        $url = 'https://i.instagram.com/api/v1/' . $endpoint;

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_PROXY, $this->proxy()['proxy']);
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $this->proxy()['auth']);
        curl_setopt($ch, CURLOPT_PROXYPORT, $this->proxy()['port']);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(['signed_body' => 'SIGNATURE.' . json_encode($post)]));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_ENCODING, "");
        curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);


        $retry_count = 6;
        $attempt = 0;
        $response = '';

        while ($attempt < $retry_count) {
            $response = curl_exec($ch);

            if (curl_errno($ch)) {

                $error_code = curl_errno($ch);
                $error_message = curl_error($ch);

                $error_log = "Curl Hatası [Kod: $endpoint]: $error_message";
                $log_filename = "../log/" . basename($error_code) . "_" . date("Y-m-d_H-i-s") . ".log";
                file_put_contents($log_filename, $error_log);

                usleep(1000000);

                $attempt++;
            } else {
                break;
            }
        }

        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $headers = substr($response, 0, $headerSize);
        $body = substr($response, $headerSize);

        curl_close($ch);

        return [
            'headers' => $headers,
            'body' => $body,
        ];
    }
}
