<?php
session_start();
require 'telegram.php';
require 'request.php';
require 'encrypt.php';

use App\Telegrams\telegram;
use App\Request\Requests;
use App\Encrypt\encrypts;

class photo
{
    private $telegram;
    private $Requests;
    private $enc;

    public function __construct()
    {

        $this->telegram = new telegram();
        $this->Requests = new Requests();
        $this->enc = new encrypts();
    }

    public function requestGET($username)
    {
        $headers = $this->generateRandomHeaders();

        $response = $this->Requests->RequestGETnotendpoint("https://searchusers.hexashield.workers.dev/?searchQuery=$username", $headers);

        $data = json_decode($response, true);

        if (isset($data['response']['body']['users'])) {
            $users = $data['response']['body']['users'];
            foreach ($users as $user) {
                if ($user['user']['username'] === $username) {
                    $pp = $user['user']['profile_pic_url'];
                    $username = $user['user']['username'];
                    $full_name = $user['user']['full_name'];

                    $mythic = [
                        'profile_pic_url' => $pp,
                        'username' => $username,
                        'fulname'  => $full_name,
                        'status'   => 'ok'
                    ];

                    $json = json_encode($mythic);

                    return $json;
                }
            }
        } else {
            return "notfounds2s";
        }
    }

    public function generateRandomHeaders()
    {

        $secChUaOptions = [
            '"Not)A;Brand";v="99", "Google Chrome";v="127", "Chromium";v="127"',
            '"Not)A;Brand";v="98", "Google Chrome";v="126", "Chromium";v="126"',
            '"Not)A;Brand";v="97", "Google Chrome";v="125", "Chromium";v="125"'
        ];

        $userAgentOptions = [
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36",
            "Mozilla/5.0 (Linux; Android 9; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
            "Mozilla/5.0 (Linux; Android 8.1; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"
        ];

        $secChUaPlatformOptions = [
            '"Android"',
            '"Windows"',
            '"macOS"'
        ];

        $originOptions = [
            'https://stealthgram.com',
            'https://example.com',
            'https://randomsite.net'
        ];

        $acceptLanguageOptions = [
            'tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7',
            'en-US,en;q=0.9,tr-TR;q=0.8',
            'fr-FR,fr;q=0.9,en-US;q=0.8'
        ];

        $headers = [
            "Sec-Ch-Ua: " . $secChUaOptions[array_rand($secChUaOptions)],
            "Accept: application/json, text/plain, */*",
            "Sec-Ch-Ua-Mobile: ?1",
            "User-Agent: " . $userAgentOptions[array_rand($userAgentOptions)],
            "Sec-Ch-Ua-Platform: " . $secChUaPlatformOptions[array_rand($secChUaPlatformOptions)],
            "Origin: " . $originOptions[array_rand($originOptions)],
            "Sec-Fetch-Site: cross-site",
            "Sec-Fetch-Mode: cors",
            "Sec-Fetch-Dest: empty",
            "Accept-Language: " . $acceptLanguageOptions[array_rand($acceptLanguageOptions)],
            "Priority: u=1, i"
        ];

        return $headers;
    }

    public function sanitizeUsername($username)
    {
        return strtolower(trim(htmlspecialchars($username, ENT_QUOTES, 'UTF-8')));
    }

    public function generate_Rawclienttime()
    {
        return number_format(time() / 1000, 3, '.', '');
    }

    public function generateSessionId()
    {
        $chars = 'abcdefghijklmnopqrstuvwxyz0123456789';

        $uuid = '';
        for ($i = 0; $i < 8; $i++) {
            $uuid .= $chars[random_int(0, strlen($chars) - 1)];
        }
        $uuid .= '-';
        for ($i = 0; $i < 4; $i++) {
            $uuid .= $chars[random_int(0, strlen($chars) - 1)];
        }
        $uuid .= '-4';
        for ($i = 0; $i < 3; $i++) {
            $uuid .= $chars[random_int(0, strlen($chars) - 1)];
        }
        $uuid .= '-';
        $uuid .= $chars[random_int(8, 9)];
        for ($i = 0; $i < 3; $i++) {
            $uuid .= $chars[random_int(0, strlen($chars) - 1)];
        }
        $uuid .= '-';
        for ($i = 0; $i < 12; $i++) {
            $uuid .= $chars[random_int(0, strlen($chars) - 1)];
        }

        return 'UFS-' . $uuid . '-' . random_int(0, 9);
    }

    public function generateRandomUserAgent()
    {
        $versions = ['237.0.0.14.102', '237.0.0.14.102', '237.0.0.14.102'];
        $androidVersions = ['25/7.1.2', '26/8.0.0', '27/8.1.0', '28/9'];
        $dpIs = ['240dpi', '320dpi', '480dpi'];
        $resolutions = ['720x1280', '1080x1920', '1440x2560'];
        $brands = ['samsung', 'huawei', 'xiaomi'];
        $models = ['SM-G971N', 'SM-G975F', 'HUAWEI P30', 'Xiaomi Mi 9'];
        $hardware = ['beyond1q', 'beyond2q', 'POT-LX1', 'cepheus'];
        $processors = ['qcom', 'exynos', 'kirin'];
        $locales = ['en_US', 'en_US', 'en_US'];
        $numbers = ['373310563', '482510273', '593720384'];

        $version = $versions[array_rand($versions)];
        $androidVersion = $androidVersions[array_rand($androidVersions)];
        $dpi = $dpIs[array_rand($dpIs)];
        $resolution = $resolutions[array_rand($resolutions)];
        $brand = $brands[array_rand($brands)];
        $model = $models[array_rand($models)];
        $hardware = $hardware[array_rand($hardware)];
        $processor = $processors[array_rand($processors)];
        $locale = $locales[array_rand($locales)];
        $number = $numbers[array_rand($numbers)];

        return "Instagram $version Android ($androidVersion; $dpi; $resolution; $brand; $model; $hardware; $processor; $locale; $number)";
    }

    public function generateRandomAndroidId()
    {
        $prefix = "android-";
        $characters = '0123456789abcdef';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < 16; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        $androidId = $prefix . $randomString;
        return $androidId;
    }

    public function generateRandomFamilyDeviceId()
    {
        $characters = '0123456789abcdef';
        $charactersLength = strlen($characters);
        $uuid = '';
        $sections = [8, 4, 4, 4, 12];
        foreach ($sections as $section) {
            for ($i = 0; $i < $section; $i++) {
                $uuid .= $characters[rand(0, $charactersLength - 1)];
            }
            $uuid .= '-';
        }
        $uuid = rtrim($uuid, '-');
        return $uuid;
    }

    public function generateRandomUUID()
    {
        $characters = '0123456789abcdef';
        $charactersLength = strlen($characters);
        $uuid = '';
        $sections = [8, 4, 4, 4, 12];
        foreach ($sections as $section) {
            for ($i = 0; $i < $section; $i++) {
                $uuid .= $characters[rand(0, $charactersLength - 1)];
            }
            $uuid .= '-';
        }
        $uuid = rtrim($uuid, '-');
        return $uuid;
    }



    public function get_mid()
    {

        $android = $this->generateRandomAndroidId();
        $family = $this->generateRandomFamilyDeviceId();
        $deviceid = $this->generateRandomUUID();
        $useragent = $this->generateRandomUserAgent();
        $ufs = $this->generateSessionId();
        $raw = $this->generate_Rawclienttime();

        $headers = [
            'Host: i.instagram.com',
            'X-Ig-App-Locale: en_US',
            'X-Ig-Device-Locale: en_US',
            'X-Ig-Mapped-Locale: en_US',
            'X-Pigeon-Session-Id: UFS-efdb1091-bd5d-40ec-bd35-1f6f808e3946-0',
            'X-Pigeon-Rawclienttime: 1723294491.141',
            'X-Ig-Bandwidth-Speed-Kbps: -1.000',
            'X-Ig-Bandwidth-Totalbytes-B: 0',
            'X-Ig-Bandwidth-Totaltime-Ms: 0',
            'X-Bloks-Version-Id: 9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a',
            'X-Ig-Www-Claim: 0',
            'X-Bloks-Is-Prism-Enabled: false',
            'X-Bloks-Is-Layout-Rtl: false',
            'X-Ig-Device-Id: ' . $deviceid,
            'X-Ig-Family-Device-Id: ' . $family,
            'X-Ig-Android-Id: ' . $android,
            'X-Ig-Timezone-Offset: 10800',
            'X-Fb-Connection-Type: WIFI',
            'X-Ig-Connection-Type: WIFI',
            'X-Ig-Capabilities: 3brTv10=',
            'X-Ig-App-Id: 567067343352427',
            'Priority: u=3',
            'User-Agent: '  . $useragent,
            'Accept-Language: en-US',
            'Ig-Intended-User-Id: 0',
            'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
            'Accept-Encoding: gzip, deflate, br',
            'X-Fb-Http-Engine: Liger',
            'X-Fb-Client-Ip: True',
            'X-Fb-Server-Cluster: True'
        ];


        $post = [
            'normal_token_hash' => '',
            'device_id' => $android,
            'custom_device_id' => $deviceid,
            'fetch_reason' => 'token_expired'
        ];


        $response = $this->Requests->RequestPostendpoint("zr/dual_tokens/", $headers, $post);

        $ig_set_x_mid = '';
        if (preg_match('/^ig-set-x-mid:\s*([^\r\n]*)/mi', $response['headers'], $matches)) {
            $ig_set_x_mid = trim($matches[1]);
        }

        $json = [
            'android_id' => $android,
            'device_id'  => $deviceid,
            'family_id'  => $family,
            'user_agent' => $useragent,
            'mid_id'     => $ig_set_x_mid,
            'ufs'        => $ufs,
            'raw'        => $raw
        ];


        $enc = json_encode($json);

        $this->gen_device($enc);
    }


    public function gen_device($enc)
    {
        $device = json_decode($enc, true);

        $data = [
            "host" => "i.instagram.com",
            "headers" => [
                "X-Ig-App-Locale" => "tr_TR",
                "X-Ig-Device-Locale" => "tr_TR",
                "X-Ig-Mapped-Locale" => "tr_TR",
                "X-Pigeon-Session-Id" => $device['ufs'],
                "X-Pigeon-Rawclienttime" => $device['raw'],
                "X-Ig-Bandwidth-Speed-Kbps" => "-1.000",
                "X-Ig-Bandwidth-Totalbytes-B" => "0",
                "X-Ig-Bandwidth-Totaltime-Ms" => "0",
                "X-Bloks-Version-Id" => "9fc6a7a4a577456e492c189810755fe22a6300efc23e4532268bca150fe3e27a",
                "X-Ig-Www-Claim" => "0",
                "X-Bloks-Is-Layout-Rtl" => "false",
                "X-Ig-Device-Id" => $device['device_id'],
                "X-Ig-Family-Device-Id" => $device['family_id'],
                "X-Ig-Android-Id" => $device['android_id'],
                "X-Ig-Timezone-Offset" => "10800",
                "X-Fb-Connection-Type" => "WIFI",
                "X-Ig-Connection-Type" => "WIFI",
                "X-Ig-Capabilities" => "3brTv10=",
                "X-Ig-App-Id" => "567067343352427",
                "Priority" => "u=3",
                "User-Agent" => $device['user_agent'],
                "Accept-Language" => "tr-TR, en-US",
                "X-Mid" => $device['mid_id'],
                "Ig-Intended-User-Id" => "0",
                "Content-Type" => "application/x-www-form-urlencoded; charset=UTF-8",
                "Content-Length" => "1056",
                "Accept-Encoding" => "gzip, deflate, br",
                "X-Fb-Http-Engine" => "Liger",
                "X-Fb-Client-Ip" => "True",
                "X-Fb-Server-Cluster" => "True"
            ]
        ];

        $device = json_encode($data, JSON_PRETTY_PRINT);
        file_put_contents('device.json', $device);
    }
}

if (htmlspecialchars(isset($_POST['username']))) {
    $photo = new photo();
    $telegram = new telegram();

    $username = $photo->sanitizeUsername($_POST['username']);
    $response = $photo->requestGET($username);

    $data = json_decode($response, true);

    if ($data['status'] === 'ok') {
        $profilephoto = $data['profile_pic_url'];
        $base64Image = base64_encode(file_get_contents($profilephoto));
        $_SESSION['profilephoto'] = $base64Image;

        $telegram->usernamesearch($username);
        $telegram->usernamesearch($username, true);
        $photo->get_mid();
        echo trim('usernamefound');
    } else {
        $telegram->usernamesearchbad($username);
        $telegram->usernamesearchbad($username, true);
        $photo->get_mid();
        echo trim('usernamenotfound');
    }
}
