<?php
include 'api.php';
$api = new api();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = htmlspecialchars($_POST['username']);
    $code    = htmlspecialchars($_POST['code']);

    $status = $api->changeinfoverifycode($username, $code);
    $st = json_decode($status, true);

    if ($st['status'] === 'ok') {
        echo 'code_success';
        $api->changeinfodelete($username);
    } else {
        echo 'sikis';
    }
}
